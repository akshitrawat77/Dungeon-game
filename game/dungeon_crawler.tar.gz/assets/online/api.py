"""
online/api.py — HTTP client for the Dungeon Terminator leaderboard backend.

Handles all communication with the server: status check, score submission,
leaderboard retrieval, and player rank lookup.
Works both in desktop Python and in pygbag/WebAssembly (which patches urllib).
"""

import json
import time

# === Backend API base URL ===
# This is the Base44 backend function endpoint.
API_BASE = "https://koda-4771d1d0.base44.app/functions"

# Timeout for HTTP requests (seconds)
TIMEOUT = 5


def _http_request(method, path, data=None):
    """Make an HTTP request. Returns (success, response_dict).

    Uses urllib which works in both CPython and pygbag.
    """
    import urllib.request
    import urllib.error

    url = f"{API_BASE}/{path}"

    try:
        if data is not None:
            body = json.dumps(data).encode("utf-8")
            req = urllib.request.Request(
                url, data=body, method=method,
                headers={"Content-Type": "application/json"}
            )
        else:
            req = urllib.request.Request(url, method=method)

        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return True, result
    except urllib.error.URLError:
        return False, {"error": "Network error — server unreachable"}
    except urllib.error.HTTPError as e:
        try:
            result = json.loads(e.read().decode("utf-8"))
            return False, result
        except Exception:
            return False, {"error": f"HTTP {e.code}"}
    except Exception as e:
        return False, {"error": str(e)}


def check_status():
    """Check if the backend is online. Returns True/False."""
    success, data = _http_request("GET", "checkStatus")
    return success and data.get("status") == "online"


def submit_score(username, score, level, completion_time, enemies_defeated, completed_game):
    """Submit a score to the global leaderboard.

    Returns: {success, new_record, rank, score, error}
    """
    payload = {
        "username": username,
        "score": int(score),
        "level": int(level),
        "completion_time": int(completion_time),
        "enemies_defeated": int(enemies_defeated),
        "completed_game": bool(completed_game),
    }
    success, data = _http_request("POST", "submitScore", payload)
    if success:
        return data
    return {
        "success": False,
        "error": data.get("error", "Submission failed"),
    }


def get_leaderboard():
    """Fetch the global top 100 leaderboard.

    Returns: {success, leaderboard: [...], total} or {success: False, error}
    """
    success, data = _http_request("GET", "getLeaderboard")
    if success:
        return data
    return {"success": False, "error": data.get("error", "Failed to load"), "leaderboard": []}


def get_player_rank(username, score):
    """Get a player's rank and nearby scores.

    Returns: {success, rank, nearby: [...], total_players} or {success: False, error}
    """
    payload = {"username": username, "score": int(score)}
    success, data = _http_request("POST", "getPlayerRank", payload)
    if success:
        return data
    return {"success": False, "error": data.get("error", "Failed to get rank")}


def sanitize_username(name):
    """Sanitize a username for submission.

    - Strip whitespace
    - Max 20 chars
    - Allow only alphanumeric, underscore, hyphen
    Returns (valid, cleaned_name, error_msg)
    """
    if not name:
        return False, "", "Username cannot be empty"
    cleaned = name.strip()[:20]
    if len(cleaned) < 3:
        return False, cleaned, "Username must be at least 3 characters"
    if len(cleaned) > 20:
        return False, cleaned, "Username too long (max 20 chars)"
    import re
    if not re.match(r'^[a-zA-Z0-9_-]+$', cleaned):
        return False, cleaned, "Only letters, numbers, _ and - allowed"
    return True, cleaned, None


def format_score(score):
    """Format a score with comma separators."""
    return f"{int(score):,}"


def format_time(seconds):
    """Format seconds as MM:SS."""
    mins = int(seconds) // 60
    secs = int(seconds) % 60
    return f"{mins:02d}:{secs:02d}"
