"""
menu.py — Main menu, username entry, controls screen, online status.
"""

import pygame
from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT, DARK_BG, WHITE, UI_GOLD, UI_NEON,
    FONT_SMALL, FONT_MEDIUM, FONT_LARGE, FONT_XL,
    ONLINE_GREEN, OFFLINE_RED, HUD_BG, HUD_BORDER,
    STATE_USERNAME, STATE_LEADERBOARD,
)
from online.api import check_status, sanitize_username


class MainMenu:
    """Main menu with PLAY GAME, LEADERBOARD, CONTROLS, QUIT options."""

    def __init__(self):
        self.selected = 0
        self.options = ["PLAY GAME", "LEADERBOARD", "CONTROLS", "QUIT"]
        self.show_controls = False
        self.title_pulse = 0.0
        self.online = False
        self.username = ""

    def update(self, dt):
        self.title_pulse += dt * 2

    def check_online_status(self):
        """Check if backend is reachable."""
        self.online = check_status()

    def handle_event(self, event):
        """Returns action string: 'start', 'leaderboard', 'quit', or None."""
        if event.type != pygame.KEYDOWN:
            return None

        if self.show_controls:
            if event.key in (pygame.K_ESCAPE, pygame.K_RETURN, pygame.K_SPACE):
                self.show_controls = False
            return None

        if event.key in (pygame.K_UP, pygame.K_w):
            self.selected = (self.selected - 1) % len(self.options)
        elif event.key in (pygame.K_DOWN, pygame.K_s):
            self.selected = (self.selected + 1) % len(self.options)
        elif event.key in (pygame.K_RETURN, pygame.K_SPACE):
            if self.selected == 0:
                return "start"
            elif self.selected == 1:
                return "leaderboard"
            elif self.selected == 2:
                self.show_controls = True
            elif self.selected == 3:
                return "quit"
        elif event.key == pygame.K_ESCAPE:
            return "quit"
        return None

    def draw(self, surface):
        surface.fill(DARK_BG)

        # Background grid effect
        for x in range(0, SCREEN_WIDTH, 40):
            pygame.draw.line(surface, (14, 16, 28), (x, 0), (x, SCREEN_HEIGHT))
        for y in range(0, SCREEN_HEIGHT, 40):
            pygame.draw.line(surface, (14, 16, 28), (0, y), (SCREEN_WIDTH, y))

        if self.show_controls:
            self._draw_controls(surface)
            return

        # === Online status indicator ===
        status_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)
        if self.online:
            pygame.draw.circle(surface, ONLINE_GREEN, (SCREEN_WIDTH - 90, 25), 6)
            status_text = status_font.render("ONLINE", True, ONLINE_GREEN)
        else:
            pygame.draw.circle(surface, OFFLINE_RED, (SCREEN_WIDTH - 90, 25), 6)
            status_text = status_font.render("OFFLINE", True, OFFLINE_RED)
        surface.blit(status_text, (SCREEN_WIDTH - 75, 17))

        # === Title ===
        title_font = pygame.font.SysFont("consolas", FONT_XL, bold=True)
        sub_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)

        pulse = 0.7 + 0.3 * abs(self.title_pulse % 2 - 1)
        title = title_font.render("DUNGEON TERMINATOR", True, UI_NEON)
        surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 120))

        sub = sub_font.render("SURVIVE THE DUNGEON", True, UI_GOLD)
        surface.blit(sub, (SCREEN_WIDTH // 2 - sub.get_width() // 2, 195))

        # === Menu options ===
        opt_font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
        y = 320
        for i, option in enumerate(self.options):
            color = UI_NEON if i == self.selected else (120, 130, 150)
            text = opt_font.render(option, True, color)
            tx = SCREEN_WIDTH // 2 - text.get_width() // 2
            if i == self.selected:
                arrow = opt_font.render(">", True, UI_NEON)
                surface.blit(arrow, (tx - 30, y))
            surface.blit(text, (tx, y))
            y += 50

        # Footer hint
        hint_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)
        hint = hint_font.render("UP/DOWN to navigate  ENTER to select", True, (80, 90, 110))
        surface.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, SCREEN_HEIGHT - 40))

    def _draw_controls(self, surface):
        title_font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
        med_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
        small_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)

        title = title_font.render("CONTROLS", True, UI_NEON)
        surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 120))

        controls = [
            ("ARROW KEYS / WASD", "Move"),
            ("MOUSE", "Aim gun"),
            ("LEFT CLICK", "Shoot"),
            ("ESC", "Pause / Menu"),
            ("R", "Restart level (after death)"),
            ("ENTER", "Start / Continue"),
        ]

        y = 220
        for key, action in controls:
            key_text = med_font.render(key, True, UI_GOLD)
            surface.blit(key_text, (SCREEN_WIDTH // 2 - 200, y))
            action_text = med_font.render(action, True, WHITE)
            surface.blit(action_text, (SCREEN_WIDTH // 2 + 20, y))
            y += 42

        # Scoring info
        y += 20
        score_title = small_font.render("SCORING", True, UI_NEON)
        surface.blit(score_title, (SCREEN_WIDTH // 2 - score_title.get_width() // 2, y))
        y += 25

        score_info = [
            "Basic Enemy: +100   Fast: +150   Ranged: +200   Tank: +300",
            "Mini Boss: +1,000   Final Boss: +5,000",
            "Level Bonuses: +500 to +5,000 (increasing per level)",
            "Time Bonus: Faster completion = more points",
            "Survival Bonus: +500 per level with no deaths",
            "Perfect Run: +10,000 for completing all 10 levels with no deaths",
        ]
        for line in score_info:
            text = small_font.render(line, True, (160, 170, 190))
            surface.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, y))
            y += 22

        hint = small_font.render("Press ENTER or ESC to go back", True, (80, 90, 110))
        surface.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, SCREEN_HEIGHT - 50))


class UsernameEntry:
    """Username entry screen shown before starting the game."""

    def __init__(self):
        self.text = ""
        self.cursor_blink = 0.0
        self.error_msg = ""

    def update(self, dt):
        self.cursor_blink += dt

    def handle_event(self, event):
        """Returns 'start' when username is submitted, 'back' on ESC, or None."""
        if event.type != pygame.KEYDOWN:
            return None

        if event.key == pygame.K_ESCAPE:
            return "back"

        if event.key == pygame.K_RETURN:
            valid, name, err = sanitize_username(self.text)
            if valid:
                self.text = name
                self.error_msg = ""
                return "start"
            else:
                self.error_msg = err
                return None

        if event.key == pygame.K_BACKSPACE:
            self.text = self.text[:-1]
            self.error_msg = ""
            return None

        # Add character if valid
        char = event.unicode
        if char and char.isprintable() and len(self.text) < 20:
            # Allow alphanumeric, underscore, hyphen
            if char.isalnum() or char in "_-":
                self.text += char
                self.error_msg = ""
        return None

    def draw(self, surface, online=False):
        surface.fill(DARK_BG)

        # Background grid
        for x in range(0, SCREEN_WIDTH, 40):
            pygame.draw.line(surface, (14, 16, 28), (x, 0), (x, SCREEN_HEIGHT))
        for y in range(0, SCREEN_HEIGHT, 40):
            pygame.draw.line(surface, (14, 16, 28), (0, y), (SCREEN_WIDTH, y))

        # Title
        title_font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
        med_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
        small_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)

        title = title_font.render("ENTER YOUR NAME", True, UI_NEON)
        surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 200))

        # Input box
        box_w = 400
        box_h = 50
        box_x = SCREEN_WIDTH // 2 - box_w // 2
        box_y = 280

        pygame.draw.rect(surface, HUD_BG, (box_x, box_y, box_w, box_h))
        pygame.draw.rect(surface, UI_NEON if not self.error_msg else (255, 80, 80),
                        (box_x, box_y, box_w, box_h), 2)

        # Text in box
        text_font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
        display_text = self.text
        # Cursor blink
        if int(self.cursor_blink * 2) % 2 == 0:
            display_text += "|"

        text_render = text_font.render(display_text, True, WHITE)
        surface.blit(text_render, (box_x + 15, box_y + 10))

        # Placeholder text
        if not self.text:
            placeholder = text_font.render("Type your name...", True, (60, 70, 90))
            surface.blit(placeholder, (box_x + 15, box_y + 10))

        # Error message
        if self.error_msg:
            err = med_font.render(self.error_msg, True, (255, 80, 80))
            surface.blit(err, (SCREEN_WIDTH // 2 - err.get_width() // 2, box_y + 60))

        # Instructions
        info_lines = [
            "3-20 characters, letters/numbers/_/- only",
            "Press ENTER to start  |  ESC to go back",
        ]
        y = box_y + 100
        for line in info_lines:
            text = small_font.render(line, True, (100, 110, 130))
            surface.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, y))
            y += 22

        # Online status
        status_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)
        if online:
            pygame.draw.circle(surface, ONLINE_GREEN, (SCREEN_WIDTH - 90, 25), 6)
            surface.blit(status_font.render("ONLINE", True, ONLINE_GREEN), (SCREEN_WIDTH - 75, 17))
        else:
            pygame.draw.circle(surface, OFFLINE_RED, (SCREEN_WIDTH - 90, 25), 6)
            surface.blit(status_font.render("OFFLINE", True, OFFLINE_RED), (SCREEN_WIDTH - 75, 17))
            warn = small_font.render("ONLINE SCORE SUBMISSION UNAVAILABLE", True, (200, 100, 100))
            surface.blit(warn, (SCREEN_WIDTH // 2 - warn.get_width() // 2, y + 20))
