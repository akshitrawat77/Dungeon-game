"""
main.py — Game entry point. Manages state machine, game loop, scoring, online.

Run with: python main.py
Requires: pip install pygame
"""

import pygame
import sys
import math
import random
import time as _time

from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT, FPS, TILE_SIZE, MAX_LEVELS, LEVELS,
    STATE_MENU, STATE_PLAYING, STATE_PAUSED, STATE_DEAD,
    STATE_TRANSITION, STATE_LEVEL_COMPLETE, STATE_WIN,
    STATE_USERNAME, STATE_LEADERBOARD, STATE_SUBMITTING, STATE_SCORE_RESULT,
    WHITE, DARK_BG, UI_NEON, UI_GOLD,
)
from camera import Camera
from player import Player
from enemy import create_enemy
from boss import MiniBoss, FinalBoss
from bullet import Bullet
from dungeon import Dungeon
from level import Level
from effects import EffectManager
from scoring import ScoreManager, ENEMY_SCORES
from ui import (
    draw_hud, draw_boss_health_bar, draw_tutorial, draw_fade,
    draw_level_transition, draw_death_screen, draw_win_screen,
    draw_pause_screen, draw_level_clear, draw_level_complete_bonus,
    draw_score_submit_result,
)
from menu import MainMenu, UsernameEntry
from online.api import check_status, submit_score, get_leaderboard, sanitize_username
from online.leaderboard import LeaderboardView


class SoundManager:
    """Handles all game sounds. Generates simple synth sounds."""

    def __init__(self):
        self.enabled = True
        self.sounds = {}
        self._init_sounds()

    def _init_sounds(self):
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=256)
        except pygame.error:
            self.enabled = False
            return
        self.sounds["shoot"] = self._gen_shoot()
        self.sounds["hit"] = self._gen_hit()
        self.sounds["death"] = self._gen_death()
        self.sounds["player_hit"] = self._gen_player_hit()
        self.sounds["door"] = self._gen_door()
        self.sounds["level"] = self._gen_level()
        self.sounds["victory"] = self._gen_victory()
        self.sounds["boss"] = self._gen_boss()

    def _gen_shoot(self):
        try:
            import numpy as np
            sr = 22050; dur = 0.1
            t = np.arange(int(sr * dur)) / sr
            freq = 800 - 600 * (t / dur)
            wave = 0.3 * np.sin(2 * math.pi * freq * t) * np.exp(-8 * t)
            stereo = np.column_stack([wave, wave])
            return pygame.sndarray.make_sound((stereo * 32767).astype(np.int16))
        except:
            return None

    def _gen_hit(self):
        try:
            import numpy as np
            sr = 22050; dur = 0.08
            t = np.arange(int(sr * dur)) / sr
            noise = np.random.uniform(-1, 1, len(t)) * 0.3
            wave = noise * np.exp(-15 * t)
            stereo = np.column_stack([wave, wave])
            return pygame.sndarray.make_sound((stereo * 32767).astype(np.int16))
        except:
            return None

    def _gen_death(self):
        try:
            import numpy as np
            sr = 22050; dur = 0.3
            t = np.arange(int(sr * dur)) / sr
            freq = 200 * (1 - t / dur)
            wave = 0.3 * np.sin(2 * math.pi * freq * t) * np.exp(-5 * t)
            stereo = np.column_stack([wave, wave])
            return pygame.sndarray.make_sound((stereo * 32767).astype(np.int16))
        except:
            return None

    def _gen_player_hit(self):
        try:
            import numpy as np
            sr = 22050; dur = 0.2
            t = np.arange(int(sr * dur)) / sr
            wave = 0.4 * np.sin(2 * math.pi * 100 * t) * np.exp(-8 * t)
            stereo = np.column_stack([wave, wave])
            return pygame.sndarray.make_sound((stereo * 32767).astype(np.int16))
        except:
            return None

    def _gen_door(self):
        try:
            import numpy as np
            sr = 22050; dur = 0.4
            t = np.arange(int(sr * dur)) / sr
            freq = 400 + 300 * (t / dur)
            wave = 0.25 * np.sin(2 * math.pi * freq * t) * np.exp(-3 * t)
            stereo = np.column_stack([wave, wave])
            return pygame.sndarray.make_sound((stereo * 32767).astype(np.int16))
        except:
            return None

    def _gen_level(self):
        try:
            import numpy as np
            sr = 22050; dur = 0.6
            t = np.arange(int(sr * dur)) / sr
            freq = 523 + 262 * (t / dur)
            wave = 0.2 * np.sin(2 * math.pi * freq * t) * np.exp(-2 * t)
            stereo = np.column_stack([wave, wave])
            return pygame.sndarray.make_sound((stereo * 32767).astype(np.int16))
        except:
            return None

    def _gen_victory(self):
        try:
            import numpy as np
            sr = 22050; dur = 1.0
            t = np.arange(int(sr * dur)) / sr
            wave = np.zeros(len(t))
            for f in [523, 659, 784, 1046]:
                wave += 0.1 * np.sin(2 * math.pi * f * t)
            wave *= np.exp(-2 * t)
            stereo = np.column_stack([wave, wave])
            return pygame.sndarray.make_sound((stereo * 32767).astype(np.int16))
        except:
            return None

    def _gen_boss(self):
        try:
            import numpy as np
            sr = 22050; dur = 0.8
            t = np.arange(int(sr * dur)) / sr
            freq = 80 + 20 * np.sin(2 * math.pi * 5 * t)
            wave = 0.3 * np.sin(2 * math.pi * freq * t)
            stereo = np.column_stack([wave, wave])
            return pygame.sndarray.make_sound((stereo * 32767).astype(np.int16))
        except:
            return None

    def play(self, name, volume=0.5):
        if not self.enabled: return
        s = self.sounds.get(name)
        if s: s.set_volume(volume); s.play()

    def play_shoot(self): self.play("shoot", 0.3)
    def play_hit(self): self.play("hit", 0.4)
    def play_death(self): self.play("death", 0.5)
    def play_player_hit(self): self.play("player_hit", 0.6)
    def play_door(self): self.play("door", 0.5)
    def play_level(self): self.play("level", 0.5)
    def play_victory(self): self.play("victory", 0.6)
    def play_boss(self): self.play("boss", 0.5)


class Game:
    """Main game controller — manages states, levels, scoring, online, and the game loop."""

    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.RESIZABLE)
        pygame.display.set_caption("Dungeon Terminator")
        self.clock = pygame.time.Clock()
        self.state = STATE_MENU
        self.menu = MainMenu()
        self.username_entry = UsernameEntry()
        self.sound = SoundManager()
        self.scoring = ScoreManager()
        self.leaderboard_view = LeaderboardView()

        self.level_num = 1
        self.level = None
        self.player = None
        self.camera = None
        self.effects = EffectManager()
        self.player_bullets = []
        self.enemy_bullets = []

        self.fade_alpha = 0.0
        self.transition_timer = 0.0
        self.show_level_text = False
        self.level_text_timer = 0.0
        self.tutorial_active = False
        self.tutorial_timer = 5.0
        self.clear_text_timer = 0.0
        self.show_clear_text = False

        self.mouse_pos = (0, 0)
        self.mouse_world = (0, 0)
        self.mouse_down = False

        # Online status
        self.online = False
        self.username = ""

        # Level complete breakdown
        self.level_breakdown = None

        # Score submission
        self.submit_result = None
        self.perfect_run = False

        # Track total game time
        self.game_time = 0.0  # accumulates during gameplay only
        self.level_time = 0.0

        # Check online on startup
        self._check_online()

    def _check_online(self):
        """Check if the backend is reachable."""
        try:
            self.online = check_status()
            self.menu.online = self.online
        except Exception:
            self.online = False
            self.menu.online = False

    def start_game(self):
        """Start a new game from level 1."""
        self.level_num = 1
        self.game_time = 0.0
        self.scoring = ScoreManager()
        self.scoring.start_game(_time.time())
        self._load_level()

    def _load_level(self):
        """Load the current level."""
        self.level = Level(self.level_num)
        spawn_x, spawn_y = self.level.get_spawn_pixel()
        self.player = Player(spawn_x, spawn_y)
        self.camera = Camera(self.level.dungeon.pixel_w, self.level.dungeon.pixel_h)
        self.camera.reset(spawn_x, spawn_y)
        self.player_bullets.clear()
        self.enemy_bullets.clear()
        self.effects.clear()
        self.state = STATE_TRANSITION
        self.transition_timer = 0.0
        self.show_level_text = True
        self.level_text_timer = 2.0
        self.tutorial_active = self.level.config.get("tutorial", False)
        self.tutorial_timer = 8.0
        self.clear_text_timer = 0.0
        self.show_clear_text = False
        self.level_time = 0.0
        self.scoring.start_level(self.level_num, _time.time())
        self.sound.play_level()

    def _restart_level(self):
        """Restart current level (after death or pause)."""
        self._load_level()

    def _next_level(self):
        """Advance to the next level or win the game."""
        if self.level_num >= MAX_LEVELS:
            # Game complete!
            total_time = self.scoring.get_completion_time(_time.time())
            self.perfect_run = self.scoring.deaths_this_run == 0
            self.scoring.complete_game(total_time)
            self.state = STATE_WIN
            self.sound.play_victory()
            return
        self.level_num += 1
        self._load_level()

    def _quit_to_menu(self):
        self.state = STATE_MENU
        self.level = None
        self.player = None
        self.camera = None

    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if self.state == STATE_MENU:
                action = self.menu.handle_event(event)
                if action == "start":
                    self.state = STATE_USERNAME
                elif action == "leaderboard":
                    self.state = STATE_LEADERBOARD
                    self.leaderboard_view.fetch()
                elif action == "quit":
                    pygame.quit()
                    sys.exit()

            elif self.state == STATE_USERNAME:
                action = self.username_entry.handle_event(event)
                if action == "start":
                    self.username = self.username_entry.text
                    self.start_game()
                elif action == "back":
                    self.state = STATE_MENU

            elif self.state == STATE_LEADERBOARD:
                action = self.leaderboard_view.handle_event(event)
                if action == "back":
                    self.state = STATE_MENU

            elif self.state == STATE_PLAYING:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state = STATE_PAUSED
                    elif event.key == pygame.K_r:
                        self._restart_level()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        self.mouse_down = True
                if event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 1:
                        self.mouse_down = False
                if event.type == pygame.MOUSEMOTION:
                    self.mouse_pos = event.pos

            elif self.state == STATE_PAUSED:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.state = STATE_PLAYING
                    elif event.key == pygame.K_r:
                        self._restart_level()
                        self.state = STATE_PLAYING
                    elif event.key == pygame.K_m:
                        self._quit_to_menu()

            elif self.state == STATE_DEAD:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self._restart_level()
                    elif event.key == pygame.K_ESCAPE:
                        self._quit_to_menu()

            elif self.state == STATE_LEVEL_COMPLETE:
                if event.type == pygame.KEYDOWN:
                    if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                        self._next_level()

            elif self.state == STATE_WIN:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        # Submit score
                        self.state = STATE_SUBMITTING
                        self._submit_score()
                    elif event.key == pygame.K_l:
                        self.state = STATE_LEADERBOARD
                        self.leaderboard_view.fetch(self.username, self.scoring.total_score)
                    elif event.key == pygame.K_p:
                        self.start_game()
                    elif event.key == pygame.K_ESCAPE:
                        self._quit_to_menu()

            elif self.state == STATE_SCORE_RESULT:
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r and self.submit_result and not self.submit_result.get("success"):
                        self._submit_score()
                    elif event.key == pygame.K_l:
                        self.state = STATE_LEADERBOARD
                        self.leaderboard_view.fetch(self.username, self.scoring.total_score)
                    elif event.key == pygame.K_p:
                        self.start_game()
                    elif event.key == pygame.K_ESCAPE:
                        self._quit_to_menu()

    def _submit_score(self):
        """Submit the player's score to the online leaderboard."""
        data = self.scoring.get_total_data()
        if not self.online:
            self.submit_result = {"success": False, "error": "Offline mode — score not uploaded"}
            self.state = STATE_SCORE_RESULT
            return

        result = submit_score(
            username=self.username,
            score=data["score"],
            level=data["level"],
            completion_time=data["completion_time"],
            enemies_defeated=data["enemies_defeated"],
            completed_game=data["completed_game"],
        )
        self.submit_result = result
        self.state = STATE_SCORE_RESULT

    def update(self, dt):
        if self.state == STATE_MENU:
            self.menu.update(dt)

        elif self.state == STATE_USERNAME:
            self.username_entry.update(dt)
            self.username_entry.text = self.username_entry.text  # keep text

        elif self.state == STATE_LEADERBOARD:
            self.leaderboard_view.update(dt)

        elif self.state == STATE_TRANSITION:
            self.transition_timer += dt
            if self.transition_timer > 1.0:
                self.state = STATE_PLAYING
            if self.camera and self.player:
                self.camera.update(self.player.x, self.player.y, dt)

        elif self.state == STATE_PLAYING:
            self._update_gameplay(dt)

        elif self.state == STATE_PAUSED:
            pass

        elif self.state == STATE_DEAD:
            if self.effects:
                self.effects.update(dt)

        elif self.state == STATE_LEVEL_COMPLETE:
            self.effects.update(dt)
            if self.camera:
                self.camera.update(self.player.x, self.player.y, dt)

        elif self.state == STATE_WIN:
            self.effects.update(dt)

        elif self.state == STATE_SUBMITTING:
            pass  # Score is being submitted (synchronous, state changes when done)

        elif self.state == STATE_SCORE_RESULT:
            pass

    def _update_gameplay(self, dt):
        keys = pygame.key.get_pressed()
        self.mouse_pos = pygame.mouse.get_pos()
        self.game_time += dt
        self.level_time += dt

        if self.camera:
            self.mouse_world = self.camera.get_mouse_world(self.mouse_pos[0], self.mouse_pos[1])
        else:
            self.mouse_world = self.mouse_pos

        walls = self.level.dungeon.walls

        # Update player
        self.player.update(dt, keys, self.mouse_pos, self.mouse_world, walls, self.camera, self.effects)

        # Handle shooting
        if self.mouse_down and self.player.can_shoot():
            self.player.shoot(self.mouse_world, self.player_bullets, self.effects)
            self.sound.play_shoot()
            self.camera.add_shake(1.5)

        # Update player bullets
        for b in self.player_bullets:
            b.update(dt, walls)
            for enemy in self.level.enemies:
                if enemy.alive and b.alive and b.get_rect().colliderect(enemy.get_rect()):
                    killed = enemy.take_damage(b.damage)
                    self.effects.add_hit_spark(b.x, b.y, enemy.color, count=5)
                    self.effects.add_damage_number(enemy.x, enemy.y, b.damage)
                    self.sound.play_hit()
                    if killed:
                        self.sound.play_death()
                        self.camera.add_shake(3)
                        # === Scoring: enemy killed ===
                        enemy_type = getattr(enemy, 'etype', 'basic')
                        points = self.scoring.add_enemy_kill(enemy_type)
                        self.effects.add_float_text(enemy.x, enemy.y, f"+{points}", color=(220, 180, 40), life=1.5, font_size=20)
                    b.alive = False
                    break

            if self.level.boss and self.level.boss.alive and b.alive:
                if b.get_rect().colliderect(self.level.boss.get_rect()):
                    killed = self.level.boss.take_damage(b.damage)
                    self.effects.add_hit_spark(b.x, b.y, (200, 50, 200), count=6)
                    self.effects.add_damage_number(self.level.boss.x, self.level.boss.y, b.damage)
                    self.sound.play_hit()
                    self.camera.add_shake(2)
                    if killed:
                        self.sound.play_death()
                        self.camera.add_shake(10)
                        # === Scoring: boss killed ===
                        boss_type = "final_boss" if self.level.config.get("final_boss") else "mini_boss"
                        points = self.scoring.add_enemy_kill(boss_type)
                        self.effects.add_float_text(self.level.boss.x, self.level.boss.y, f"+{points}", color=(255, 215, 0), life=2.0, font_size=28)
                    b.alive = False

        self.player_bullets = [b for b in self.player_bullets if b.alive]

        # Update enemy bullets
        for b in self.enemy_bullets:
            b.update(dt, walls)
            if b.alive and self.player.alive and b.get_rect().colliderect(self.player.get_rect()):
                if self.player.take_damage(b.damage):
                    self.sound.play_player_hit()
                    self.camera.add_shake(4)
                    self.effects.add_hit_spark(b.x, b.y, (255, 50, 50), count=4)
                b.alive = False

        self.enemy_bullets = [b for b in self.enemy_bullets if b.alive]

        # Update level
        self.level.update(dt, self.player, walls, self.enemy_bullets, self.effects)

        # Check if player died
        if not self.player.alive:
            self.state = STATE_DEAD
            self.scoring.register_death()
            self.effects.add_explosion(self.player.x, self.player.y, (80, 140, 240), count=20)
            self.camera.add_shake(8)
            return

        # Show "Dungeon Cleared" text
        if self.level.cleared and not self.show_clear_text:
            self.show_clear_text = True
            self.clear_text_timer = 0.0
            self.sound.play_door()
            if self.level.config.get("pre_boss"):
                self.effects.add_float_text(self.player.x, self.player.y - 60,
                    "FINAL CHAMBER AHEAD", color=(255, 100, 100), life=3.0, font_size=24)

        if self.show_clear_text:
            self.clear_text_timer += dt
            if self.clear_text_timer > 3.5:
                self.show_clear_text = False

        # Check exit
        if self.level.check_exit(self.player):
            # === Scoring: level complete ===
            level_time = self.scoring.get_level_time(_time.time())
            self.level_breakdown = self.scoring.complete_level(self.level_num, level_time)
            self.state = STATE_LEVEL_COMPLETE
            self.sound.play_level()

        # Update camera
        self.camera.update(self.player.x, self.player.y, dt)

        # Update effects
        self.effects.update(dt)

        # Tutorial
        if self.tutorial_active:
            self.tutorial_timer -= dt
            if (self.player.moving and self.player.has_shot) or self.tutorial_timer <= 0:
                self.tutorial_active = False

        # Level text
        if self.show_level_text:
            self.level_text_timer -= dt
            if self.level_text_timer <= 0:
                self.show_level_text = False

    def draw(self):
        self.screen.fill(DARK_BG)

        if self.state == STATE_MENU:
            self.menu.draw(self.screen)

        elif self.state == STATE_USERNAME:
            self.username_entry.draw(self.screen, self.online)

        elif self.state == STATE_LEADERBOARD:
            self.leaderboard_view.draw(self.screen)

        elif self.state in (STATE_PLAYING, STATE_TRANSITION, STATE_PAUSED,
                            STATE_DEAD, STATE_LEVEL_COMPLETE, STATE_WIN,
                            STATE_SUBMITTING, STATE_SCORE_RESULT):
            if self.level and self.player:
                # Draw dungeon
                self.level.dungeon.draw(self.screen, self.camera)

                # Draw health pickups
                for pickup in self.level.health_pickups:
                    if pickup.alive:
                        pickup.draw(self.screen, self.camera)

                # Draw enemy bullets
                for b in self.enemy_bullets:
                    b.draw(self.screen, self.camera)

                # Draw enemies
                for enemy in self.level.enemies:
                    enemy.draw(self.screen, self.camera)

                # Draw boss
                if self.level.boss:
                    self.level.boss.draw(self.screen, self.camera)

                # Draw player bullets
                for b in self.player_bullets:
                    b.draw(self.screen, self.camera)

                # Draw player
                self.player.draw(self.screen, self.camera)

                # Draw effects
                self.effects.draw(self.screen, self.camera)

                # Draw HUD with score
                objective = self.level.config.get("objective", "")
                if self.level.cleared:
                    objective = "EXIT UNLOCKED - GO TO THE EXIT"
                draw_hud(self.screen, self.player, self.level_num,
                         self.level.get_alive_count(), objective, self.level.config,
                         score=self.scoring.total_score,
                         enemies_defeated=self.scoring.enemies_defeated)

                # Boss health bar
                if self.level.boss and self.level.boss.alive:
                    boss_name = "FINAL BOSS" if self.level.config.get("final_boss") else "MINI BOSS"
                    draw_boss_health_bar(self.screen, self.level.boss, boss_name)

                # Tutorial
                if self.tutorial_active and self.state == STATE_PLAYING:
                    draw_tutorial(self.screen, self.player, 0)

                # Level transition text
                if self.show_level_text:
                    draw_level_transition(self.screen, self.level_num,
                                         self.level.config.get("objective", ""), 200)

                # Dungeon cleared text
                if self.show_clear_text:
                    draw_level_clear(self.screen, self.clear_text_timer)

                # State-specific overlays
                if self.state == STATE_PAUSED:
                    draw_pause_screen(self.screen)

                if self.state == STATE_DEAD:
                    draw_death_screen(self.screen)

                if self.state == STATE_LEVEL_COMPLETE and self.level_breakdown:
                    draw_level_complete_bonus(self.screen, self.level_breakdown, self.level_num)

                if self.state == STATE_WIN:
                    total_time = self.scoring.total_time
                    draw_win_screen(self.screen,
                                    total_score=self.scoring.total_score,
                                    total_time=total_time,
                                    enemies_defeated=self.scoring.enemies_defeated,
                                    perfect_run=self.perfect_run)

                if self.state == STATE_SUBMITTING:
                    draw_score_submit_result(self.screen, None, self.username, self.scoring.total_score)

                if self.state == STATE_SCORE_RESULT:
                    draw_score_submit_result(self.screen, self.submit_result, self.username, self.scoring.total_score)

            # Transition fade
            if self.state == STATE_TRANSITION:
                alpha = 255 * (1.0 - min(1.0, self.transition_timer))
                if self.transition_timer < 0.5:
                    alpha = 255 * (1.0 - self.transition_timer / 0.5)
                else:
                    alpha = 0
                draw_fade(self.screen, alpha)

        pygame.display.flip()

    def run(self):
        while True:
            dt = self.clock.tick(FPS) / 1000.0
            dt = min(dt, 0.05)
            self.handle_events()
            self.update(dt)
            self.draw()


if __name__ == "__main__":
    game = Game()
    game.run()
