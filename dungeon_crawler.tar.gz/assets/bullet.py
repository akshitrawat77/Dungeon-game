"""
bullet.py — Bullet / projectile system for player and enemy shots.
"""

import pygame
import math
from settings import (
    BULLET_PLAYER, BULLET_ENEMY, BULLET_TRAIL_P, BULLET_TRAIL_E,
    BULLET_LIFETIME, SCREEN_WIDTH, SCREEN_HEIGHT,
)


class Bullet:
    """A single projectile traveling in a direction.

    owner = "player" or "enemy" — determines collision and color.
    """

    def __init__(self, x, y, dx, dy, speed, damage, owner="player", size=4):
        self.x = x
        self.y = y
        self.dx = dx * speed
        self.dy = dy * speed
        self.damage = damage
        self.owner = owner
        self.size = size
        self.lifetime = BULLET_LIFETIME
        self.alive = True
        self.trail = []  # list of (x, y) for trail effect
        self.max_trail = 5

    def update(self, dt, walls):
        """Move the bullet, check wall collision, update lifetime."""
        self.trail.append((self.x, self.y))
        if len(self.trail) > self.max_trail:
            self.trail.pop(0)

        self.x += self.dx * dt
        self.y += self.dy * dt

        self.lifetime -= dt
        if self.lifetime <= 0:
            self.alive = False
            return

        # Wall collision (AABB with wall rects)
        rect = pygame.Rect(self.x - self.size, self.y - self.size, self.size * 2, self.size * 2)
        for wall in walls:
            if rect.colliderect(wall):
                self.alive = False
                return

        # Off-screen safety (in world coords — handled by camera bounds)
        # We let lifetime handle this

    def draw(self, surface, camera):
        """Draw the bullet with a trail."""
        sx, sy = camera.apply(self.x, self.y)

        # Cull if off-screen
        if sx < -20 or sx > SCREEN_WIDTH + 20 or sy < -20 or sy > SCREEN_HEIGHT + 20:
            return

        if self.owner == "player":
            trail_color = BULLET_TRAIL_P
            core_color = BULLET_PLAYER
        else:
            trail_color = BULLET_TRAIL_E
            core_color = BULLET_ENEMY

        # Draw trail
        for i, (tx, ty) in enumerate(self.trail):
            tsx, tsy = camera.apply(tx, ty)
            alpha = (i / self.max_trail) * 0.5
            r = max(1, int(self.size * alpha))
            if r > 0:
                pygame.draw.circle(surface, trail_color, (tsx, tsy), r)

        # Draw core
        pygame.draw.circle(surface, core_color, (sx, sy), self.size)
        # Bright center
        pygame.draw.circle(surface, WHITE if self.owner == "player" else (255, 200, 200),
                           (sx, sy), max(1, self.size // 2))

    def get_rect(self):
        return pygame.Rect(self.x - self.size, self.y - self.size, self.size * 2, self.size * 2)


WHITE = (240, 240, 245)
