"""
enemy.py — Enemy classes: Basic, Fast, Ranged, Tank.
"""

import pygame
import math
import random
from settings import (
    ENEMY_TYPES, ENEMY_EYE, TILE_SIZE,
    BULLET_ENEMY, SCREEN_WIDTH, SCREEN_HEIGHT,
)
from bullet import Bullet


class Enemy:
    """Base enemy class. Subclasses override AI behavior via update_ai()."""

    def __init__(self, x, y, etype="basic"):
        cfg = ENEMY_TYPES[etype]
        self.etype = etype
        self.x = x
        self.y = y
        self.width = cfg["size"]
        self.height = cfg["size"]
        self.max_health = cfg["hp"]
        self.health = cfg["hp"]
        self.speed = cfg["speed"]
        self.damage = cfg["damage"]
        self.detection_range = cfg["range"]
        self.attack_cooldown = 0.0
        self.attack_cd_max = cfg["attack_cd"]
        self.score = cfg["score"]
        self.color = cfg["color"]
        self.alive = True
        self.hit_flash = 0.0
        self.death_timer = 0.0
        self.is_boss = False
        self.walk_anim = 0.0
        # For avoiding walls: store last valid direction
        self.last_dx = 0
        self.last_dy = 0

    def get_rect(self):
        return pygame.Rect(
            self.x - self.width // 2, self.y - self.height // 2,
            self.width, self.height,
        )

    def take_damage(self, amount):
        self.health -= amount
        self.hit_flash = 0.15
        if self.health <= 0:
            self.health = 0
            self.alive = False
            self.death_timer = 0.4
        return not self.alive  # True if killed

    def update(self, dt, player, walls, enemy_bullets, effects):
        if not self.alive:
            if self.death_timer > 0:
                self.death_timer -= dt
            return

        if self.hit_flash > 0:
            self.hit_flash -= dt
        if self.attack_cooldown > 0:
            self.attack_cooldown -= dt

        # Check if player is in detection range
        dist = math.hypot(player.x - self.x, player.y - self.y)

        if dist < self.detection_range:
            self.update_ai(dt, player, walls, enemy_bullets, effects, dist)
            self.walk_anim += dt * 6
        else:
            # Idle wander
            self.wander(dt, walls)

    def update_ai(self, dt, player, walls, enemy_bullets, effects, dist):
        """Override in subclasses."""
        # Basic: move toward player
        if dist > 0:
            dx = (player.x - self.x) / dist
            dy = (player.y - self.y) / dist
        else:
            dx, dy = 1, 0

        self.move_with_collision(dx, dy, dt, walls)

        # Melee attack on contact
        if dist < self.width + player.width and self.attack_cooldown <= 0:
            if player.take_damage(self.damage):
                self.attack_cooldown = self.attack_cd_max

    def move_with_collision(self, dx, dy, dt, walls):
        """Move toward (dx, dy) with wall collision and wall avoidance."""
        move_x = dx * self.speed * dt
        move_y = dy * self.speed * dt

        # Try X
        new_x = self.x + move_x
        rect_x = pygame.Rect(new_x - self.width // 2, self.y - self.height // 2, self.width, self.height)
        blocked_x = any(rect_x.colliderect(w) for w in walls)
        if not blocked_x:
            self.x = new_x
        else:
            # Try to slide along wall (move Y only)
            pass

        # Try Y
        new_y = self.y + move_y
        rect_y = pygame.Rect(self.x - self.width // 2, new_y - self.height // 2, self.width, self.height)
        blocked_y = any(rect_y.colliderect(w) for w in walls)
        if not blocked_y:
            self.y = new_y

        # If both blocked, try to find alternate path
        if blocked_x and blocked_y:
            # Try perpendicular directions
            for angle in [math.pi / 2, -math.pi / 2, math.pi / 4, -math.pi / 4]:
                alt_dx = math.cos(math.atan2(dy, dx) + angle)
                alt_dy = math.sin(math.atan2(dy, dx) + angle)
                alt_x = self.x + alt_dx * self.speed * dt
                alt_y = self.y + alt_dy * self.speed * dt
                rect_alt = pygame.Rect(alt_x - self.width // 2, alt_y - self.height // 2, self.width, self.height)
                if not any(rect_alt.colliderect(w) for w in walls):
                    self.x = alt_x
                    self.y = alt_y
                    break

    def wander(self, dt, walls):
        """Slowly wander when player is out of range."""
        if random.random() < 0.02:
            self.last_dx = random.uniform(-1, 1)
            self.last_dy = random.uniform(-1, 1)
            length = math.hypot(self.last_dx, self.last_dy)
            if length > 0:
                self.last_dx /= length
                self.last_dy /= length

        if self.last_dx != 0 or self.last_dy != 0:
            self.move_with_collision(self.last_dx, self.last_dy, dt * 0.3, walls)

    def draw(self, surface, camera):
        if not self.alive:
            return

        sx, sy = camera.apply(self.x, self.y)
        if sx < -30 or sx > SCREEN_WIDTH + 30 or sy < -30 or sy > SCREEN_HEIGHT + 30:
            return

        flash = self.hit_flash > 0
        color = (255, 255, 255) if flash else self.color

        bob = int(math.sin(self.walk_anim) * 2)

        # Body
        half = self.width // 2
        pygame.draw.rect(surface, color, (sx - half, sy - half + bob, self.width, self.height))
        pygame.draw.rect(surface, (20, 20, 20), (sx - half, sy - half + bob, self.width, self.height), 1)

        # Eyes (robot visor)
        eye_y = sy - self.height // 4 + bob
        pygame.draw.rect(surface, ENEMY_EYE, (sx - 5, eye_y, 10, 3))

        # Health bar (small, above enemy)
        if self.health < self.max_health:
            bar_w = self.width + 4
            bar_h = 3
            bar_x = sx - bar_w // 2
            bar_y = sy - half - 8
            pygame.draw.rect(surface, (40, 10, 10), (bar_x, bar_y, bar_w, bar_h))
            fill = int(bar_w * (self.health / self.max_health))
            pygame.draw.rect(surface, (50, 220, 80), (bar_x, bar_y, fill, bar_h))


class FastEnemy(Enemy):
    """Fast, low-health, aggressive."""

    def __init__(self, x, y):
        super().__init__(x, y, "fast")

    def update_ai(self, dt, player, walls, enemy_bullets, effects, dist):
        # Charge directly at player
        if dist > 0:
            dx = (player.x - self.x) / dist
            dy = (player.y - self.y) / dist
        else:
            dx, dy = 1, 0

        self.move_with_collision(dx, dy, dt, walls)

        # Attack on contact
        if dist < self.width + player.width and self.attack_cooldown <= 0:
            if player.take_damage(self.damage):
                self.attack_cooldown = self.attack_cd_max


class RangedEnemy(Enemy):
    """Keeps distance and shoots projectiles at the player."""

    def __init__(self, x, y):
        super().__init__(x, y, "ranged")
        cfg = ENEMY_TYPES["ranged"]
        self.bullet_speed = cfg["bullet_speed"]
        self.bullet_damage = cfg["bullet_damage"]
        self.preferred_dist = 250

    def update_ai(self, dt, player, walls, enemy_bullets, effects, dist):
        # Move to maintain preferred distance
        if dist > 0:
            dx = (player.x - self.x) / dist
            dy = (player.y - self.y) / dist
        else:
            dx, dy = 0, 1

        if dist > self.preferred_dist + 30:
            # Move closer
            self.move_with_collision(dx, dy, dt, walls)
        elif dist < self.preferred_dist - 30:
            # Back away
            self.move_with_collision(-dx, -dy, dt, walls)
        else:
            # Strafe
            strafe_dx = -dy
            strafe_dy = dx
            self.move_with_collision(strafe_dx, strafe_dy, dt * 0.5, walls)

        # Shoot if in range and cooldown ready
        if dist < self.detection_range and self.attack_cooldown <= 0:
            # Check line of sight (simple: just shoot)
            bullet = Bullet(
                self.x, self.y, dx, dy, self.bullet_speed,
                self.bullet_damage, owner="enemy", size=4
            )
            enemy_bullets.append(bullet)
            self.attack_cooldown = self.attack_cd_max

    def draw(self, surface, camera):
        super().draw(surface, camera)
        # Add a "gun" indicator
        if self.alive:
            sx, sy = camera.apply(self.x, self.y)
            # Small indicator on top
            pygame.draw.rect(surface, (140, 60, 180), (sx - 2, sy - self.height // 2 - 4, 4, 4))


class TankEnemy(Enemy):
    """High health, slow, high damage. Very tough."""

    def __init__(self, x, y):
        super().__init__(x, y, "tank")

    def update_ai(self, dt, player, walls, enemy_bullets, effects, dist):
        # Slowly move toward player
        if dist > 0:
            dx = (player.x - self.x) / dist
            dy = (player.y - self.y) / dist
        else:
            dx, dy = 1, 0

        self.move_with_collision(dx, dy, dt, walls)

        # Heavy melee
        if dist < self.width + player.width and self.attack_cooldown <= 0:
            if player.take_damage(self.damage):
                self.attack_cooldown = self.attack_cd_max

    def draw(self, surface, camera):
        if not self.alive:
            return
        sx, sy = camera.apply(self.x, self.y)
        if sx < -30 or sx > SCREEN_WIDTH + 30 or sy < -30 or sy > SCREEN_HEIGHT + 30:
            return

        flash = self.hit_flash > 0
        color = (255, 255, 255) if flash else self.color

        # Tank is bigger and bulkier
        half = self.width // 2
        # Armor plating
        pygame.draw.rect(surface, (60, 65, 80), (sx - half - 2, sy - half - 2, self.width + 4, self.height + 4))
        pygame.draw.rect(surface, color, (sx - half, sy - half, self.width, self.height))
        pygame.draw.rect(surface, (30, 30, 40), (sx - half, sy - half, self.width, self.height), 2)
        # Red eye strip
        pygame.draw.rect(surface, (255, 60, 60), (sx - 7, sy - 3, 14, 4))
        # Bolts
        for ox, oy in [(-half + 3, -half + 3), (half - 4, -half + 3), (-half + 3, half - 4), (half - 4, half - 4)]:
            pygame.draw.circle(surface, (40, 42, 50), (sx + ox, sy + oy), 2)

        # Health bar
        if self.health < self.max_health:
            bar_w = self.width + 8
            bar_h = 4
            bar_x = sx - bar_w // 2
            bar_y = sy - half - 10
            pygame.draw.rect(surface, (40, 10, 10), (bar_x, bar_y, bar_w, bar_h))
            fill = int(bar_w * (self.health / self.max_health))
            pygame.draw.rect(surface, (50, 220, 80), (bar_x, bar_y, fill, bar_h))


def create_enemy(etype, x, y):
    """Factory function to create an enemy of the given type."""
    if etype == "basic":
        return Enemy(x, y, "basic")
    elif etype == "fast":
        return FastEnemy(x, y)
    elif etype == "ranged":
        return RangedEnemy(x, y)
    elif etype == "tank":
        return TankEnemy(x, y)
    else:
        return Enemy(x, y, "basic")
