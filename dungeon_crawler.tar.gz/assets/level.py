"""
level.py — Level management: spawns enemies, manages exit state, transitions.
"""

import random
import pygame
from settings import LEVELS, TILE_SIZE, ENEMY_TYPES
from dungeon import Dungeon
from enemy import create_enemy
from boss import MiniBoss, FinalBoss


class HealthPickup:
    """A health pickup that restores player HP."""

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.size = 16
        self.alive = True
        self.bob = 0.0
        self.heal_amount = 25

    def update(self, dt):
        self.bob += dt * 3

    def get_rect(self):
        return pygame.Rect(self.x - self.size, self.y - self.size, self.size * 2, self.size * 2)

    def draw(self, surface, camera):
        from settings import HEALTH_GREEN, HEALTH_DARK
        sx, sy = camera.apply(self.x, self.y)
        offset = int(math.sin(self.bob) * 3)

        # Cross/plus shape
        pygame.draw.rect(surface, HEALTH_DARK, (sx - 10, sy - 10 + offset, 20, 20), border_radius=3)
        pygame.draw.rect(surface, HEALTH_GREEN, (sx - 8, sy - 8 + offset, 16, 16), border_radius=2)
        # White cross
        pygame.draw.rect(surface, (240, 255, 240), (sx - 5, sy - 1 + offset, 10, 3))
        pygame.draw.rect(surface, (240, 255, 240), (sx - 1, sy - 5 + offset, 3, 10))


import math


class Level:
    """Manages a single level: dungeon, enemies, boss, pickups, exit state."""

    def __init__(self, level_num):
        self.level_num = level_num
        config = LEVELS[level_num - 1]
        self.config = config
        self.dungeon = Dungeon(config["w"], config["h"])
        self.dungeon.generate()
        self.dungeon.exit_locked = True

        self.boss = None
        self.enemies = []
        self.health_pickups = []
        self.enemies_remaining = 0
        self.cleared = False
        self.transition_text_shown = False

        self._spawn_enemies(config)
        self._spawn_boss(config)
        self._spawn_pickups(config)

    def _spawn_enemies(self, config):
        """Spawn enemies on floor tiles, away from player spawn."""
        spawn_room = None
        if self.dungeon.rooms:
            spawn_room = self.dungeon.rooms[0]

        positions = self.dungeon.get_floor_positions(
            exclude_room=spawn_room,
            min_dist_from_spawn=5
        )
        random.shuffle(positions)

        count = config["enemies"]
        types = config["types"]

        for i in range(min(count, len(positions))):
            tx, ty = positions[i]
            px = tx * TILE_SIZE + TILE_SIZE // 2
            py = ty * TILE_SIZE + TILE_SIZE // 2
            etype = types[i % len(types)]
            self.enemies.append(create_enemy(etype, px, py))

        self.enemies_remaining = len(self.enemies) + (1 if self.boss else 0)

    def _spawn_boss(self, config):
        """Spawn boss if this level has one."""
        if config.get("boss") == "mini":
            # Place in last room
            if self.dungeon.rooms:
                room = self.dungeon.rooms[-1]
                bx = room.centerx * TILE_SIZE + TILE_SIZE // 2
                by = room.centery * TILE_SIZE + TILE_SIZE // 2
                self.boss = MiniBoss(bx, by)
        elif config.get("boss") == "final":
            # Place in last room, centered
            if self.dungeon.rooms:
                room = self.dungeon.rooms[-1]
                bx = room.centerx * TILE_SIZE + TILE_SIZE // 2
                by = room.centery * TILE_SIZE + TILE_SIZE // 2
                self.boss = FinalBoss(bx, by)

    def _spawn_pickups(self, config):
        """Spawn health pickups."""
        count = config.get("health_pickups", 0)
        if count == 0:
            return

        spawn_room = self.dungeon.rooms[0] if self.dungeon.rooms else None
        positions = self.dungeon.get_floor_positions(
            exclude_room=spawn_room,
            min_dist_from_spawn=8
        )
        random.shuffle(positions)

        for i in range(min(count, len(positions))):
            tx, ty = positions[i]
            px = tx * TILE_SIZE + TILE_SIZE // 2
            py = ty * TILE_SIZE + TILE_SIZE // 2
            self.health_pickups.append(HealthPickup(px, py))

    def update(self, dt, player, walls, enemy_bullets, effects):
        """Update all level entities."""
        # Update enemies
        for enemy in self.enemies:
            enemy.update(dt, player, walls, enemy_bullets, effects)

        # Update boss
        if self.boss and self.boss.alive:
            self.boss.update(dt, player, walls, enemy_bullets, effects, spawn_callback=self._spawn_minion)

        # Update pickups
        for pickup in self.health_pickups:
            if pickup.alive:
                pickup.update(dt)
                # Check player collision
                if player.get_rect().colliderect(pickup.get_rect()):
                    player.heal(pickup.heal_amount)
                    pickup.alive = False
                    effects.add_float_text(pickup.x, pickup.y, "+25 HP", color=(50, 220, 80), life=1.5, font_size=18)

        # Remove dead pickups
        self.health_pickups = [p for p in self.health_pickups if p.alive]

        # Remove dead enemies (after death animation)
        alive_enemies = []
        for e in self.enemies:
            if e.alive or e.death_timer > 0:
                alive_enemies.append(e)
            else:
                # Enemy just died
                effects.add_explosion(e.x, e.y, e.color, count=15)
                effects.add_damage_number(e.x, e.y, e.score, color=(220, 180, 40))
                camera_shake = 3 if not e.etype == "tank" else 6
        self.enemies = alive_enemies

        # Remove dead boss
        if self.boss and not self.boss.alive and self.boss.death_timer <= 0:
            effects.add_explosion(self.boss.x, self.boss.y, (200, 50, 200), count=30)
            effects.add_float_text(self.boss.x, self.boss.y, "BOSS DEFEATED!", color=(255, 100, 255), life=2.5, font_size=28)
            self.boss = None

        # Check if all enemies and boss are dead
        living = len([e for e in self.enemies if e.alive]) + (1 if (self.boss and self.boss.alive) else 0)
        self.enemies_remaining = living

        if living == 0 and not self.cleared:
            self.cleared = True
            self.dungeon.exit_locked = False

    def _spawn_minion(self):
        """Spawn a basic enemy near the boss (for final boss fight)."""
        if not self.boss:
            return
        # Find a floor tile near the boss
        bx, by = self.dungeon.tile_at_pixel(self.boss.x, self.boss.y)
        for _ in range(10):
            tx = bx + random.randint(-3, 3)
            ty = by + random.randint(-3, 3)
            if self.dungeon.is_floor(tx, ty):
                px = tx * TILE_SIZE + TILE_SIZE // 2
                py = ty * TILE_SIZE + TILE_SIZE // 2
                e = create_enemy("fast", px, py)
                self.enemies.append(e)
                break

    def get_alive_count(self):
        """Count of living enemies (including boss)."""
        count = sum(1 for e in self.enemies if e.alive)
        if self.boss and self.boss.alive:
            count += 1
        return count

    def check_exit(self, player):
        """Check if player has reached the exit tile."""
        if self.cleared:
            px, py = player.x, player.y
            ex, ey = self.dungeon.get_exit_pixel()
            dist = (px - ex) ** 2 + (py - ey) ** 2
            if dist < (TILE_SIZE * 0.7) ** 2:
                return True
        return False

    def get_spawn_pixel(self):
        return self.dungeon.get_spawn_pixel()
