"""
dungeon.py — Procedural dungeon generation with rooms, corridors, and collision.
"""

import random
import pygame
from settings import TILE_SIZE


# Tile types
WALL = 0
FLOOR = 1
EXIT = 2


class Dungeon:
    """A tile-based dungeon map with wall rectangles for collision.

    Generates a dungeon with rooms connected by corridors.
    Guarantees a path from player spawn to exit via BFS validation.
    """

    def __init__(self, width, height):
        self.width = width   # in tiles
        self.height = height  # in tiles
        self.tiles = [[WALL for _ in range(width)] for _ in range(height)]
        self.rooms = []
        self.spawn_tile = (1, 1)
        self.exit_tile = (width - 2, height - 2)
        self.exit_locked = True
        self.pixel_w = width * TILE_SIZE
        self.pixel_h = height * TILE_SIZE
        self.walls = []  # pygame.Rect list for collision
        self.decorations = []  # (tile_x, tile_y, type) for visual flair

    def generate(self):
        """Generate the dungeon layout using rooms + corridors."""
        self.tiles = [[WALL for _ in range(self.width)] for _ in range(self.height)]
        self.rooms = []

        room_attempts = max(8, (self.width * self.height) // 200)
        min_room = 4
        max_room = 8

        for _ in range(room_attempts):
            rw = random.randint(min_room, max_room)
            rh = random.randint(min_room, max_room)
            rx = random.randint(1, self.width - rw - 2)
            ry = random.randint(1, self.height - rh - 2)

            new_room = pygame.Rect(rx, ry, rw, rh)

            # Check overlap with existing rooms
            overlap = False
            for room in self.rooms:
                if new_room.inflate(2, 2).colliderect(room):
                    overlap = True
                    break

            if overlap:
                continue

            # Carve room
            for ty in range(ry, ry + rh):
                for tx in range(rx, rx + rw):
                    self.tiles[ty][tx] = FLOOR

            # Connect to previous room with corridor
            if self.rooms:
                prev = self.rooms[-1]
                # L-shaped corridor
                cx1 = prev.centerx
                cy1 = prev.centery
                cx2 = new_room.centerx
                cy2 = new_room.centery

                if random.choice([True, False]):
                    self._carve_h(cx1, cx2, cy1)
                    self._carve_v(cy1, cy2, cx2)
                else:
                    self._carve_v(cy1, cy2, cx1)
                    self._carve_h(cx1, cx2, cy2)

            self.rooms.append(new_room)

        # Player spawn: first room center
        if self.rooms:
            self.spawn_tile = (self.rooms[0].centerx, self.rooms[0].centery)

        # Exit: last room center
        if len(self.rooms) > 1:
            self.exit_tile = (self.rooms[-1].centerx, self.rooms[-1].centery)

        self.tiles[self.exit_tile[1]][self.exit_tile[0]] = EXIT

        # Add some decorations (on wall tiles adjacent to floor)
        self._add_decorations()

        # Build wall rects
        self._build_walls()

    def _carve_h(self, x1, x2, y):
        for x in range(min(x1, x2), max(x1, x2) + 1):
            if 0 < x < self.width - 1 and 0 < y < self.height - 1:
                self.tiles[y][x] = FLOOR

    def _carve_v(self, y1, y2, x):
        for y in range(min(y1, y2), max(y1, y2) + 1):
            if 0 < x < self.width - 1 and 0 < y < self.height - 1:
                self.tiles[y][x] = FLOOR

    def _add_decorations(self):
        """Mark wall tiles next to floor for visual decoration."""
        self.decorations = []
        for y in range(self.height):
            for x in range(self.width):
                if self.tiles[y][x] == WALL:
                    # Check if adjacent to floor
                    for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < self.width and 0 <= ny < self.height:
                            if self.tiles[ny][nx] == FLOOR:
                                self.decorations.append((x, y))
                                break

    def _build_walls(self):
        """Create pygame.Rect objects for all wall tiles."""
        self.walls = []
        for y in range(self.height):
            for x in range(self.width):
                if self.tiles[y][x] == WALL:
                    rect = pygame.Rect(x * TILE_SIZE, y * TILE_SIZE, TILE_SIZE, TILE_SIZE)
                    self.walls.append(rect)

    def get_floor_positions(self, exclude_room=None, min_dist_from_spawn=0):
        """Get all floor tile positions, optionally excluding a room."""
        positions = []
        spawn_x, spawn_y = self.spawn_tile
        for y in range(self.height):
            for x in range(self.width):
                if self.tiles[y][x] == FLOOR:
                    if min_dist_from_spawn > 0:
                        dist = abs(x - spawn_x) + abs(y - spawn_y)
                        if dist < min_dist_from_spawn:
                            continue
                    if exclude_room:
                        if exclude_room.collidepoint(x, y):
                            continue
                    positions.append((x, y))
        return positions

    def get_spawn_pixel(self):
        """Return the pixel center of the spawn tile."""
        return (self.spawn_tile[0] * TILE_SIZE + TILE_SIZE // 2,
                self.spawn_tile[1] * TILE_SIZE + TILE_SIZE // 2)

    def get_exit_pixel(self):
        """Return the pixel center of the exit tile."""
        return (self.exit_tile[0] * TILE_SIZE + TILE_SIZE // 2,
                self.exit_tile[1] * TILE_SIZE + TILE_SIZE // 2)

    def tile_at_pixel(self, px, py):
        """Get tile coordinates from pixel position."""
        return (int(px // TILE_SIZE), int(py // TILE_SIZE))

    def draw(self, surface, camera):
        """Render the visible dungeon tiles."""
        from settings import (
            WALL_COLOR, WALL_HIGHLIGHT, WALL_SHADOW, WALL_EDGE,
            FLOOR_COLOR, FLOOR_COLOR_ALT, FLOOR_GRID,
            EXIT_LOCKED, EXIT_OPEN, EXIT_GLOW,
            BLACK,
        )

        # Calculate visible tile range
        start_tx = max(0, int(camera.x // TILE_SIZE))
        end_tx = min(self.width, int((camera.x + 1280) // TILE_SIZE) + 2)
        start_ty = max(0, int(camera.y // TILE_SIZE))
        end_ty = min(self.height, int((camera.y + 720) // TILE_SIZE) + 2)

        for ty in range(start_ty, end_ty):
            for tx in range(start_tx, end_tx):
                tile = self.tiles[ty][tx]
                px, py = camera.apply(tx * TILE_SIZE, ty * TILE_SIZE)

                if tile == WALL:
                    # Wall with 3D-ish shading
                    pygame.draw.rect(surface, WALL_COLOR, (px, py, TILE_SIZE, TILE_SIZE))
                    # Top highlight
                    pygame.draw.rect(surface, WALL_HIGHLIGHT, (px, py, TILE_SIZE, 3))
                    # Bottom shadow
                    pygame.draw.rect(surface, WALL_SHADOW, (px, py + TILE_SIZE - 3, TILE_SIZE, 3))
                    # Edge
                    pygame.draw.rect(surface, WALL_EDGE, (px, py, TILE_SIZE, TILE_SIZE), 1)

                elif tile == FLOOR:
                    # Floor with subtle grid pattern
                    color = FLOOR_COLOR if (tx + ty) % 2 == 0 else FLOOR_COLOR_ALT
                    pygame.draw.rect(surface, color, (px, py, TILE_SIZE, TILE_SIZE))
                    # Grid lines
                    pygame.draw.line(surface, FLOOR_GRID, (px, py), (px + TILE_SIZE, py), 1)
                    pygame.draw.line(surface, FLOOR_GRID, (px, py), (px, py + TILE_SIZE), 1)

                elif tile == EXIT:
                    # Exit door
                    if self.exit_locked:
                        pygame.draw.rect(surface, EXIT_LOCKED, (px, py, TILE_SIZE, TILE_SIZE))
                        # Lock icon
                        pygame.draw.circle(surface, (255, 200, 200), (px + TILE_SIZE // 2, py + TILE_SIZE // 2), 6, 2)
                    else:
                        # Unlocked — glowing green
                        pulse = 0.7 + 0.3 * math.sin(pygame.time.get_ticks() * 0.005)
                        glow_color = tuple(int(c * pulse) for c in EXIT_GLOW)
                        pygame.draw.rect(surface, EXIT_OPEN, (px, py, TILE_SIZE, TILE_SIZE))
                        pygame.draw.rect(surface, glow_color, (px + 4, py + 4, TILE_SIZE - 8, TILE_SIZE - 8))
                        # Arrow pointing right
                        cx, cy = px + TILE_SIZE // 2, py + TILE_SIZE // 2
                        pygame.draw.polygon(surface, (20, 60, 30), [
                            (cx - 6, cy - 5), (cx + 2, cy - 5),
                            (cx + 2, cy - 9), (cx + 8, cy),
                            (cx + 2, cy + 9), (cx + 2, cy + 5),
                            (cx - 6, cy + 5),
                        ])

    def is_floor(self, tx, ty):
        if 0 <= tx < self.width and 0 <= ty < self.height:
            return self.tiles[ty][tx] in (FLOOR, EXIT)
        return False


import math
