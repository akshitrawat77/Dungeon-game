"""
effects.py — Particles, damage numbers, muzzle flash, and visual effects.
"""

import pygame
import random
import math
from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT,
    PARTICLE_HIT, PARTICLE_DEATH, PARTICLE_SPARK,
    MUZZLE_FLASH, MUZZLE_FLASH_TIME,
)


class Particle:
    """A simple physics particle for hit/death/spark effects."""

    def __init__(self, x, y, vx, vy, color, life, size=3, gravity=0):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.color = color
        self.life = life
        self.max_life = life
        self.size = size
        self.gravity = gravity
        self.alive = True

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vy += self.gravity * dt
        self.vx *= 0.92  # friction
        self.vy *= 0.92
        self.life -= dt
        if self.life <= 0:
            self.alive = False

    def draw(self, surface, camera):
        sx, sy = camera.apply(self.x, self.y)
        if sx < -10 or sx > SCREEN_WIDTH + 10 or sy < -10 or sy > SCREEN_HEIGHT + 10:
            return
        alpha = max(0, min(1, self.life / self.max_life))
        r = max(1, int(self.size * alpha))
        pygame.draw.circle(surface, self.color, (sx, sy), r)


class DamageNumber:
    """A floating number that rises and fades."""

    def __init__(self, x, y, value, color=(255, 220, 80)):
        self.x = x
        self.y = y
        self.value = str(value)
        self.color = color
        self.life = 1.0
        self.max_life = 1.0
        self.vy = -60  # float upward
        self.alive = True
        self.font = pygame.font.SysFont("consolas", 16, bold=True)

    def update(self, dt):
        self.y += self.vy * dt
        self.vy *= 0.95
        self.life -= dt
        if self.life <= 0:
            self.alive = False

    def draw(self, surface, camera):
        sx, sy = camera.apply(self.x, self.y)
        alpha = max(0, min(1, self.life / self.max_life))
        text = self.font.render(self.value, True, self.color)
        text.set_alpha(int(255 * alpha))
        # Offset to center on point
        surface.blit(text, (sx - text.get_width() // 2, sy - text.get_height() // 2))


class MuzzleFlash:
    """Brief flash at gun muzzle when shooting."""

    def __init__(self, x, y, angle):
        self.x = x
        self.y = y
        self.angle = angle
        self.life = MUZZLE_FLASH_TIME
        self.alive = True

    def update(self, dt):
        self.life -= dt
        if self.life <= 0:
            self.alive = False

    def draw(self, surface, camera):
        sx, sy = camera.apply(self.x, self.y)
        alpha = max(0, self.life / MUZZLE_FLASH_TIME)
        size = int(12 * alpha)
        if size <= 0:
            return
        # Star-like flash
        spread = 0.4
        for i in range(5):
            a = self.angle + random.uniform(-spread, spread)
            x2 = sx + math.cos(a) * size * 1.5
            y2 = sy + math.sin(a) * size * 1.5
            pygame.draw.line(surface, MUZZLE_FLASH, (sx, sy), (x2, y2), 2)
        pygame.draw.circle(surface, MUZZLE_FLASH, (sx, sy), max(2, size // 2))


class Explosion:
    """A burst of particles for enemy deaths."""

    def __init__(self, x, y, color=PARTICLE_DEATH, count=12):
        self.particles = []
        for _ in range(count):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(80, 250)
            vx = math.cos(angle) * speed
            vy = math.sin(angle) * speed
            life = random.uniform(0.3, 0.7)
            self.particles.append(Particle(x, y, vx, vy, color, life, size=random.randint(2, 5)))
        # Add some sparks
        for _ in range(count // 2):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(150, 350)
            vx = math.cos(angle) * speed
            vy = math.sin(angle) * speed
            life = random.uniform(0.2, 0.5)
            self.particles.append(Particle(x, y, vx, vy, PARTICLE_SPARK, life, size=2))


class HitSpark:
    """Small spark burst when a bullet hits something."""

    def __init__(self, x, y, color=PARTICLE_HIT, count=6):
        self.particles = []
        for _ in range(count):
            angle = random.uniform(0, math.tau)
            speed = random.uniform(40, 150)
            vx = math.cos(angle) * speed
            vy = math.sin(angle) * speed
            life = random.uniform(0.15, 0.35)
            self.particles.append(Particle(x, y, vx, vy, color, life, size=random.randint(1, 3)))


class EffectManager:
    """Manages all active effects: particles, damage numbers, muzzle flashes."""

    def __init__(self):
        self.particles = []
        self.damage_numbers = []
        self.muzzle_flashes = []
        self.float_texts = []  # (x, y, text, life, max_life, color, font_size)

    def clear(self):
        self.particles.clear()
        self.damage_numbers.clear()
        self.muzzle_flashes.clear()
        self.float_texts.clear()

    def add_explosion(self, x, y, color=PARTICLE_DEATH, count=12):
        exp = Explosion(x, y, color, count)
        self.particles.extend(exp.particles)

    def add_hit_spark(self, x, y, color=PARTICLE_HIT, count=6):
        spark = HitSpark(x, y, color, count)
        self.particles.extend(spark.particles)

    def add_damage_number(self, x, y, value, color=(255, 220, 80)):
        self.damage_numbers.append(DamageNumber(x, y, value, color))

    def add_muzzle_flash(self, x, y, angle):
        self.muzzle_flashes.append(MuzzleFlash(x, y, angle))

    def add_float_text(self, x, y, text, color=(100, 255, 150), life=2.0, font_size=24):
        self.float_texts.append([x, y, text, life, life, color, font_size])

    def update(self, dt):
        for p in self.particles:
            p.update(dt)
        self.particles = [p for p in self.particles if p.alive]

        for d in self.damage_numbers:
            d.update(dt)
        self.damage_numbers = [d for d in self.damage_numbers if d.alive]

        for m in self.muzzle_flashes:
            m.update(dt)
        self.muzzle_flashes = [m for m in self.muzzle_flashes if m.alive]

        for ft in self.float_texts:
            ft[1] -= 30 * dt
            ft[3] -= dt
        self.float_texts = [ft for ft in self.float_texts if ft[3] > 0]

    def draw(self, surface, camera):
        for p in self.particles:
            p.draw(surface, camera)
        for d in self.damage_numbers:
            d.draw(surface, camera)
        for m in self.muzzle_flashes:
            m.draw(surface, camera)

        for ft in self.float_texts:
            sx, sy = camera.apply(ft[0], ft[1])
            alpha = max(0, min(1, ft[3] / ft[4]))
            font = pygame.font.SysFont("consolas", ft[6], bold=True)
            text = font.render(ft[2], True, ft[5])
            text.set_alpha(int(255 * alpha))
            surface.blit(text, (sx - text.get_width() // 2, sy - text.get_height() // 2))
