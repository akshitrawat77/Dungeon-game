"""
camera.py — Smooth camera that follows the player through the dungeon.
"""

import math
from settings import SCREEN_WIDTH, SCREEN_HEIGHT, CAMERA_LERP, CAMERA_OFFSET_Y


class Camera:
    """A camera that smoothly follows a target position.

    Usage:
        cam = Camera(dungeon_width, dungeon_height)
        cam.update(player.x, player.y, dt)
        screen_x, screen_y = cam.apply(world_x, world_y)
    """

    def __init__(self, dungeon_width, dungeon_height):
        self.x = 0.0
        self.y = 0.0
        self.dungeon_w = dungeon_width
        self.dungeon_h = dungeon_height
        # How much the dungeon extends past the screen in pixels
        self.max_x = max(0, dungeon_width - SCREEN_WIDTH)
        self.max_y = max(0, dungeon_height - SCREEN_HEIGHT)
        self.shake_x = 0.0
        self.shake_y = 0.0
        self.shake_amount = 0.0
        self.shake_decay = 8.0

    def update(self, target_x, target_y, dt):
        """Smoothly move toward target (player center)."""
        # Desired camera top-left so player is roughly centered
        desired_x = target_x - SCREEN_WIDTH / 2
        desired_y = target_y - SCREEN_HEIGHT / 2 + CAMERA_OFFSET_Y

        # Clamp to dungeon bounds
        desired_x = max(0, min(self.max_x, desired_x))
        desired_y = max(0, min(self.max_y, desired_y))

        # Smooth lerp
        lerp = 1.0 - math.exp(-CAMERA_LERP * dt)
        self.x += (desired_x - self.x) * lerp
        self.y += (desired_y - self.y) * lerp

        # Update screen shake
        if self.shake_amount > 0.1:
            self.shake_amount -= self.shake_decay * dt
            import random
            self.shake_x = random.uniform(-1, 1) * self.shake_amount
            self.shake_y = random.uniform(-1, 1) * self.shake_amount
        else:
            self.shake_x = 0.0
            self.shake_y = 0.0
            self.shake_amount = 0.0

    def add_shake(self, amount):
        """Trigger a screen shake."""
        self.shake_amount = max(self.shake_amount, amount)

    def apply(self, world_x, world_y):
        """Convert world coordinates to screen coordinates."""
        sx = world_x - self.x + self.shake_x
        sy = world_y - self.y + self.shake_y
        return int(sx), int(sy)

    def get_mouse_world(self, mouse_x, mouse_y):
        """Convert mouse screen position to world position."""
        return mouse_x + self.x - self.shake_x, mouse_y + self.y - self.shake_y

    def reset(self, target_x, target_y):
        """Instantly snap to target (used on level load)."""
        desired_x = target_x - SCREEN_WIDTH / 2
        desired_y = target_y - SCREEN_HEIGHT / 2 + CAMERA_OFFSET_Y
        self.x = max(0, min(self.max_x, desired_x))
        self.y = max(0, min(self.max_y, desired_y))
        self.shake_amount = 0.0
