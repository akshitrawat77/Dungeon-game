"""
player.py — The player character: movement, aiming, shooting, health.
"""

import pygame
import math
from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT, TILE_SIZE,
    PLAYER_MAX_HP, PLAYER_SPEED, PLAYER_SHOOT_CD, PLAYER_HIT_CD,
    BULLET_SPEED, BULLET_DAMAGE, PLAYER_RECOIL,
    PLAYER_BODY, PLAYER_DARK, PLAYER_LIGHT, PLAYER_HELMET, PLAYER_VISOR,
    GUN_BODY, GUN_DARK, GUN_BARREL, GUN_DARK,
    WHITE, BULLET_PLAYER,
)
from bullet import Bullet
from effects import EffectManager


class Player:
    """The futuristic armored soldier.

    Movement uses arrow keys (smooth, pixel-based, delta-time).
    Aiming uses mouse position. Left-click to shoot.
    """

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.width = 22
        self.height = 22
        self.max_health = PLAYER_MAX_HP
        self.health = PLAYER_MAX_HP
        self.speed = PLAYER_SPEED
        self.shoot_cooldown = 0.0
        self.shoot_cd_max = PLAYER_SHOOT_CD
        self.aim_angle = 0.0
        self.hit_cooldown = 0.0
        self.alive = True
        self.recoil = 0.0
        self.moving = False
        self.has_shot = False
        self.walk_anim = 0.0  # for bobbing animation

        # Sound placeholder
        self.shoot_sound = None

    def get_rect(self):
        return pygame.Rect(
            self.x - self.width // 2, self.y - self.height // 2,
            self.width, self.height,
        )

    def update(self, dt, keys, mouse_pos, mouse_world, walls, camera, effects):
        """Handle movement, aiming, shooting cooldown."""
        if not self.alive:
            return

        # === Movement (arrow keys) ===
        dx, dy = 0, 0
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            dy -= 1
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            dy += 1
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            dx -= 1
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            dx += 1

        self.moving = (dx != 0 or dy != 0)

        # Normalize diagonal movement
        if dx != 0 and dy != 0:
            length = math.hypot(dx, dy)
            dx /= length
            dy /= length

        move_x = dx * self.speed * dt
        move_y = dy * self.speed * dt

        # Move X, then check collision
        new_x = self.x + move_x
        rect_x = pygame.Rect(new_x - self.width // 2, self.y - self.height // 2, self.width, self.height)
        collision_x = False
        for wall in walls:
            if rect_x.colliderect(wall):
                collision_x = True
                break
        if not collision_x:
            self.x = new_x

        # Move Y, then check collision
        new_y = self.y + move_y
        rect_y = pygame.Rect(self.x - self.width // 2, new_y - self.height // 2, self.width, self.height)
        collision_y = False
        for wall in walls:
            if rect_y.colliderect(wall):
                collision_y = True
                break
        if not collision_y:
            self.y = new_y

        # Walk animation
        if self.moving:
            self.walk_anim += dt * 8

        # === Aiming ===
        self.aim_angle = math.atan2(mouse_world[1] - self.y, mouse_world[0] - self.x)

        # === Shooting cooldown ===
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= dt

        # === Recoil ===
        if self.recoil > 0:
            self.recoil -= dt * 60

        # === Hit invulnerability ===
        if self.hit_cooldown > 0:
            self.hit_cooldown -= dt

    def can_shoot(self):
        return self.alive and self.shoot_cooldown <= 0

    def shoot(self, mouse_world, bullets, effects):
        """Fire a bullet toward the mouse position."""
        if not self.can_shoot():
            return

        self.shoot_cooldown = self.shoot_cd_max
        self.has_shot = True
        self.recoil = PLAYER_RECOIL

        # Calculate gun tip position (in front of player)
        gun_len = 28
        tip_x = self.x + math.cos(self.aim_angle) * gun_len
        tip_y = self.y + math.sin(self.aim_angle) * gun_len

        # Bullet direction (normalized)
        dx = math.cos(self.aim_angle)
        dy = math.sin(self.aim_angle)

        bullet = Bullet(tip_x, tip_y, dx, dy, BULLET_SPEED, BULLET_DAMAGE, owner="player", size=4)
        bullets.append(bullet)

        # Muzzle flash
        effects.add_muzzle_flash(tip_x, tip_y, self.aim_angle)

        # Shell casing particles
        for _ in range(2):
            shell_angle = self.aim_angle + math.pi / 2 + math.pi  # eject to the side
            from effects import Particle
            sx = self.x + math.cos(self.aim_angle) * 10
            sy = self.y + math.sin(self.aim_angle) * 10
            effects.particles.append(Particle(
                sx, sy,
                math.cos(shell_angle) * 80 + random.uniform(-20, 20),
                math.sin(shell_angle) * 80 + random.uniform(-30, 10),
                (200, 180, 80), 0.4, size=2, gravity=300
            ))

    def take_damage(self, amount):
        if self.hit_cooldown > 0 or not self.alive:
            return False
        self.health -= amount
        self.hit_cooldown = PLAYER_HIT_CD
        if self.health <= 0:
            self.health = 0
            self.alive = False
        return True

    def heal(self, amount):
        self.health = min(self.max_health, self.health + amount)

    def draw(self, surface, camera):
        """Draw the pixel-art soldier with a rotating gun."""
        if not self.alive:
            return

        sx, sy = camera.apply(self.x, self.y)

        # Flash red when recently hit
        flash = self.hit_cooldown > 0 and (int(self.hit_cooldown * 20) % 2 == 0)

        # === Draw gun (rotated to aim angle) ===
        gun_surf = pygame.Surface((36, 10), pygame.SRCALPHA)
        # Gun barrel
        pygame.draw.rect(gun_surf, GUN_BARREL, (0, 3, 28, 4))
        # Gun body
        pygame.draw.rect(gun_surf, GUN_BODY, (2, 1, 16, 8))
        pygame.draw.rect(gun_surf, GUN_DARK, (2, 1, 16, 8), 1)
        # Recoil offset
        recoil_offset = int(self.recoil)
        rotated = pygame.transform.rotate(gun_surf, -math.degrees(self.aim_angle))
        rect = rotated.get_rect(center=(sx - recoil_offset, sy - recoil_offset))
        surface.blit(rotated, rect)

        # === Draw body (pixel-art robot soldier) ===
        body_color = (255, 80, 80) if flash else PLAYER_BODY
        dark_color = (180, 50, 50) if flash else PLAYER_DARK
        light_color = (255, 120, 120) if flash else PLAYER_LIGHT

        # Walking bob
        bob = int(math.sin(self.walk_anim) * 2) if self.moving else 0

        # Helmet
        pygame.draw.rect(surface, PLAYER_HELMET, (sx - 8, sy - 11 + bob, 16, 6))
        pygame.draw.rect(surface, (40, 48, 60), (sx - 8, sy - 11 + bob, 16, 6), 1)
        # Visor (glowing cyan)
        pygame.draw.rect(surface, PLAYER_VISOR, (sx - 6, sy - 9 + bob, 12, 2))
        # Body / chest armor
        pygame.draw.rect(surface, body_color, (sx - 9, sy - 5 + bob, 18, 10))
        pygame.draw.rect(surface, dark_color, (sx - 9, sy - 5 + bob, 18, 10), 1)
        # Chest light
        pygame.draw.circle(surface, light_color, (sx, sy + bob), 2)
        # Legs
        leg_offset = int(math.sin(self.walk_anim) * 3) if self.moving else 0
        pygame.draw.rect(surface, dark_color, (sx - 7, sy + 5 + bob, 5, 7 + leg_offset))
        pygame.draw.rect(surface, dark_color, (sx + 2, sy + 5 + bob, 5, 7 - leg_offset))
        # Shoulder pads
        pygame.draw.rect(surface, dark_color, (sx - 10, sy - 4 + bob, 3, 5))
        pygame.draw.rect(surface, dark_color, (sx + 7, sy - 4 + bob, 3, 5))


# Need random for shell casings
import random
