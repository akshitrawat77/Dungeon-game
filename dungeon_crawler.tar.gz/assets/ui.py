"""
ui.py — HUD, health bars, objective text, boss health bar, level transitions,
score display, level completion bonus screen, final score screen.
"""

import pygame
from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT, HUD_BG, HUD_BORDER,
    HP_GREEN, HP_RED, HP_BG, UI_GOLD, UI_NEON, WHITE,
    FONT_SMALL, FONT_MEDIUM, FONT_LARGE, FONT_XL,
)


def draw_hud(surface, player, level_num, enemies_remaining, objective, level_config,
             score=0, enemies_defeated=0):
    """Draw the main HUD: health bar, level info, enemies, objective, score."""
    hud_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
    small_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)

    # HP label + bar (top-left)
    hp_label = hud_font.render("HP", True, UI_NEON)
    surface.blit(hp_label, (16, 12))

    bar_x, bar_y, bar_w, bar_h = 55, 14, 200, 18
    pygame.draw.rect(surface, HP_BG, (bar_x, bar_y, bar_w, bar_h))
    pygame.draw.rect(surface, HUD_BORDER, (bar_x, bar_y, bar_w, bar_h), 1)

    hp_pct = player.health / player.max_health
    fill_w = int(bar_w * hp_pct)
    fill_color = HP_GREEN if hp_pct > 0.3 else HP_RED
    pygame.draw.rect(surface, fill_color, (bar_x, bar_y, fill_w, bar_h))

    hp_text = small_font.render(f"{int(player.health)}/{player.max_health}", True, WHITE)
    surface.blit(hp_text, (bar_x + bar_w // 2 - hp_text.get_width() // 2, bar_y + 1))

    # Score (top-center)
    score_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
    score_text = score_font.render(f"SCORE: {int(score):,}", True, UI_GOLD)
    surface.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, 12))

    enemies_text = small_font.render(f"Enemies Defeated: {enemies_defeated}", True, (200, 200, 220))
    surface.blit(enemies_text, (SCREEN_WIDTH // 2 - enemies_text.get_width() // 2, 38))

    # Level info (top-right)
    level_text = hud_font.render(f"LEVEL {level_num}/10", True, UI_GOLD)
    surface.blit(level_text, (SCREEN_WIDTH - level_text.get_width() - 16, 12))

    enemy_text = small_font.render(f"Enemies: {enemies_remaining}", True, (255, 120, 120))
    surface.blit(enemy_text, (SCREEN_WIDTH - enemy_text.get_width() - 16, 38))

    # Objective (bottom-center)
    obj_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
    if objective:
        text = obj_font.render(objective, True, UI_NEON)
        pill_w = text.get_width() + 24
        pill_h = 28
        pill_x = SCREEN_WIDTH // 2 - pill_w // 2
        pill_y = SCREEN_HEIGHT - 38
        pygame.draw.rect(surface, HUD_BG, (pill_x, pill_y, pill_w, pill_h), border_radius=4)
        pygame.draw.rect(surface, HUD_BORDER, (pill_x, pill_y, pill_w, pill_h), 1, border_radius=4)
        surface.blit(text, (pill_x + 12, pill_y + 4))


def draw_boss_health_bar(surface, boss, boss_name="BOSS"):
    """Draw a large health bar at the top of the screen for boss fights."""
    if not boss or not boss.alive:
        return

    bar_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
    name_text = bar_font.render(boss_name, True, (255, 100, 255))

    bar_x = SCREEN_WIDTH // 2 - 250
    bar_y = 65
    bar_w, bar_h = 500, 22

    pygame.draw.rect(surface, (20, 5, 20), (bar_x, bar_y, bar_w, bar_h))
    pygame.draw.rect(surface, (100, 30, 100), (bar_x, bar_y, bar_w, bar_h), 2)

    hp_pct = boss.health / boss.max_health
    fill_w = int(bar_w * hp_pct)
    fill_color = (180, 40, 180) if hp_pct > 0.3 else (255, 50, 50)
    pygame.draw.rect(surface, fill_color, (bar_x, bar_y, fill_w, bar_h))

    surface.blit(name_text, (SCREEN_WIDTH // 2 - name_text.get_width() // 2, bar_y - 24))
    hp_text = bar_font.render(f"{int(boss.health)}/{boss.max_health}", True, WHITE)
    surface.blit(hp_text, (SCREEN_WIDTH // 2 - hp_text.get_width() // 2, bar_y + 2))


def draw_tutorial(surface, player, dt):
    """Draw tutorial text on Level 1."""
    tutorial_font = pygame.font.SysFont("consolas", 18, bold=True)
    lines = [
        ("ARROW KEYS - MOVE", (100, 200, 255)),
        ("MOUSE - AIM", (100, 200, 255)),
        ("LEFT CLICK - SHOOT", (100, 200, 255)),
        ("DEFEAT ALL ENEMIES TO UNLOCK THE EXIT", (255, 200, 100)),
    ]

    y = SCREEN_HEIGHT // 2 - 60
    for text, color in lines:
        rendered = tutorial_font.render(text, True, color)
        bg_rect = rendered.get_rect(center=(SCREEN_WIDTH // 2, y))
        bg_rect.inflate_ip(20, 8)
        bg_surf = pygame.Surface(bg_rect.size, pygame.SRCALPHA)
        bg_surf.fill((0, 0, 0, 120))
        surface.blit(bg_surf, bg_rect)
        surface.blit(rendered, (SCREEN_WIDTH // 2 - rendered.get_width() // 2, y))
        y += 32


def draw_fade(surface, alpha):
    """Draw a black fade overlay (alpha 0-255)."""
    fade_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
    fade_surf.fill((0, 0, 0))
    fade_surf.set_alpha(int(alpha))
    surface.blit(fade_surf, (0, 0))


def draw_level_transition(surface, level_num, objective_text, alpha):
    """Draw the level transition overlay with level number and objective."""
    fade_surf = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    fade_surf.fill((0, 0, 0, min(200, alpha)))

    big_font = pygame.font.SysFont("consolas", FONT_XL, bold=True)
    small_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)

    title = big_font.render(f"LEVEL {level_num}", True, UI_GOLD)
    fade_surf.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 60))

    if objective_text:
        obj = small_font.render(objective_text, True, UI_NEON)
        fade_surf.blit(obj, (SCREEN_WIDTH // 2 - obj.get_width() // 2, SCREEN_HEIGHT // 2 + 10))

    surface.blit(fade_surf, (0, 0))


def draw_death_screen(surface):
    """Draw the YOU DIED screen."""
    big_font = pygame.font.SysFont("consolas", FONT_XL, bold=True)
    med_font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)

    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((40, 0, 0, 180))

    title = big_font.render("YOU DIED", True, (255, 50, 50))
    overlay.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 60))

    sub = med_font.render("PRESS R TO RESTART", True, WHITE)
    overlay.blit(sub, (SCREEN_WIDTH // 2 - sub.get_width() // 2, SCREEN_HEIGHT // 2 + 20))

    surface.blit(overlay, (0, 0))


def draw_win_screen(surface, total_score=0, total_time=0, enemies_defeated=0,
                     perfect_run=False, rank=None):
    """Draw the victory screen with final score and stats."""
    big_font = pygame.font.SysFont("consolas", FONT_XL, bold=True)
    med_font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
    small_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
    tiny_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)

    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 10, 5, 200))

    # Mission Complete
    title = big_font.render("MISSION COMPLETE", True, UI_GOLD)
    overlay.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 100))

    # Score
    score_label = small_font.render("SCORE", True, UI_NEON)
    overlay.blit(score_label, (SCREEN_WIDTH // 2 - score_label.get_width() // 2, 180))
    score_text = big_font.render(f"{int(total_score):,}", True, WHITE)
    overlay.blit(score_text, (SCREEN_WIDTH // 2 - score_text.get_width() // 2, 210))

    # Time
    mins = int(total_time) // 60
    secs = int(total_time) % 60
    time_text = med_font.render(f"TIME: {mins:02d}:{secs:02d}", True, UI_NEON)
    overlay.blit(time_text, (SCREEN_WIDTH // 2 - time_text.get_width() // 2, 290))

    # Enemies defeated
    enemies_text = med_font.render(f"ENEMIES DEFEATED: {enemies_defeated}", True, WHITE)
    overlay.blit(enemies_text, (SCREEN_WIDTH // 2 - enemies_text.get_width() // 2, 340))

    # Perfect run
    if perfect_run:
        perfect_text = med_font.render("PERFECT RUN! NO DEATHS! +10,000 BONUS", True, (255, 215, 0))
        overlay.blit(perfect_text, (SCREEN_WIDTH // 2 - perfect_text.get_width() // 2, 390))

    # Rank
    if rank:
        rank_text = med_font.render(f"RANK: #{rank}", True, UI_GOLD)
        overlay.blit(rank_text, (SCREEN_WIDTH // 2 - rank_text.get_width() // 2, 430))

    # Actions
    actions = "[ENTER] SUBMIT SCORE   [L] LEADERBOARD   [P] PLAY AGAIN   [ESC] MENU"
    actions_text = tiny_font.render(actions, True, (150, 160, 180))
    overlay.blit(actions_text, (SCREEN_WIDTH // 2 - actions_text.get_width() // 2, 500))

    surface.blit(overlay, (0, 0))


def draw_pause_screen(surface):
    """Draw the pause menu."""
    big_font = pygame.font.SysFont("consolas", FONT_XL, bold=True)
    med_font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)

    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))

    title = big_font.render("PAUSED", True, UI_NEON)
    overlay.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2 - 100))

    lines = ["[ESC] RESUME", "[R] RESTART LEVEL", "[M] MAIN MENU"]
    y = SCREEN_HEIGHT // 2 - 10
    for line in lines:
        text = med_font.render(line, True, WHITE)
        overlay.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, y))
        y += 45

    surface.blit(overlay, (0, 0))


def draw_level_clear(surface, timer):
    """Draw 'DUNGEON CLEARED' / 'EXIT UNLOCKED' message."""
    big_font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
    med_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)

    alpha = min(1.0, timer / 2.0) * 255 if timer < 2.0 else 255
    if timer > 2.0:
        alpha = max(0, 255 - int((timer - 2.0) * 200))

    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 20, 10, 100))

    t1 = big_font.render("DUNGEON CLEARED!", True, (50, 220, 80))
    t1.set_alpha(int(alpha))
    overlay.blit(t1, (SCREEN_WIDTH // 2 - t1.get_width() // 2, SCREEN_HEIGHT // 2 - 40))

    t2 = med_font.render("EXIT UNLOCKED", True, (100, 255, 150))
    t2.set_alpha(int(alpha))
    overlay.blit(t2, (SCREEN_WIDTH // 2 - t2.get_width() // 2, SCREEN_HEIGHT // 2 + 10))

    t3 = med_font.render("GO TO THE EXIT", True, UI_NEON)
    t3.set_alpha(int(alpha))
    overlay.blit(t3, (SCREEN_WIDTH // 2 - t3.get_width() // 2, SCREEN_HEIGHT // 2 + 40))

    surface.blit(overlay, (0, 0))


def draw_level_complete_bonus(surface, breakdown, level_num):
    """Draw the level completion bonus screen.

    breakdown: dict with level_bonus, time_bonus, survival_bonus, level_total, time, deaths
    """
    big_font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
    med_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
    small_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)

    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 10, 20, 200))

    # Title
    title = big_font.render("LEVEL COMPLETE!", True, UI_NEON)
    overlay.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 140))

    y = 220

    # Level time
    time_str = f"Level Time: {int(breakdown['time']//60):02d}:{int(breakdown['time']%60):02d}"
    text = med_font.render(time_str, True, (150, 160, 180))
    overlay.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, y))
    y += 40

    # Level bonus
    text = med_font.render(f"LEVEL BONUS: +{breakdown['level_bonus']:,}", True, UI_GOLD)
    overlay.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, y))
    y += 35

    # Time bonus
    text = med_font.render(f"TIME BONUS: +{breakdown['time_bonus']:,}", True, UI_NEON)
    overlay.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, y))
    y += 35

    # Survival bonus
    if breakdown['survival_bonus'] > 0:
        text = med_font.render(f"SURVIVAL BONUS: +{breakdown['survival_bonus']:,}", True, (50, 220, 80))
    else:
        text = med_font.render(f"SURVIVAL BONUS: +0 (died this level)", True, (150, 100, 100))
    overlay.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, y))
    y += 45

    # Total level bonus
    pygame.draw.line(overlay, HUD_BORDER,
                    (SCREEN_WIDTH // 2 - 150, y), (SCREEN_WIDTH // 2 + 150, y), 1)
    y += 10
    text = big_font.render(f"TOTAL BONUS: +{breakdown['level_total']:,}", True, UI_GOLD)
    overlay.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, y))
    y += 50

    # Continue prompt
    text = small_font.render("Press ENTER to continue", True, (100, 110, 130))
    overlay.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, y))

    surface.blit(overlay, (0, 0))


def draw_score_submit_result(surface, result, username, score):
    """Draw the score submission result screen."""
    big_font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
    med_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
    small_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)

    overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT), pygame.SRCALPHA)
    overlay.fill((0, 10, 20, 200))

    if result is None:
        # Still submitting
        title = med_font.render("SUBMITTING SCORE...", True, UI_NEON)
        overlay.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, SCREEN_HEIGHT // 2))
    elif result.get("success"):
        title = big_font.render("SCORE SUBMITTED!", True, (50, 220, 80))
        overlay.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 200))

        if result.get("new_record"):
            new_best = med_font.render("NEW PERSONAL BEST!", True, UI_GOLD)
            overlay.blit(new_best, (SCREEN_WIDTH // 2 - new_best.get_width() // 2, 260))
        else:
            prev = med_font.render(f"Previous best: {result.get('previous_best', 0):,}", True, (150, 160, 180))
            overlay.blit(prev, (SCREEN_WIDTH // 2 - prev.get_width() // 2, 260))

        rank = result.get("rank", "?")
        rank_text = med_font.render(f"YOUR RANK: #{rank}", True, UI_NEON)
        overlay.blit(rank_text, (SCREEN_WIDTH // 2 - rank_text.get_width() // 2, 310))

        actions = "[L] LEADERBOARD   [P] PLAY AGAIN   [ESC] MENU"
    else:
        title = big_font.render("SUBMISSION FAILED", True, (255, 80, 80))
        overlay.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 200))

        err = med_font.render(result.get("error", "Unknown error"), True, (200, 100, 100))
        overlay.blit(err, (SCREEN_WIDTH // 2 - err.get_width() // 2, 260))

        actions = "[R] RETRY   [P] PLAY AGAIN   [ESC] MENU"

    actions_text = small_font.render(actions, True, (100, 110, 130))
    overlay.blit(actions_text, (SCREEN_WIDTH // 2 - actions_text.get_width() // 2, 380))

    surface.blit(overlay, (0, 0))
