"""
boss.py — Mini Boss and Final Boss with multiple attack patterns.
"""

import pygame
import math
import random
from settings import (
    BOSS_BODY, BOSS_DARK, BOSS_EYE, BOSS_HP_BAR,
    MINI_BOSS_HP, MINI_BOSS_SPEED, MINI_BOSS_DMG,
    FINAL_BOSS_HP, FINAL_BOSS_SPEED, FINAL_BOSS_DMG,
    SCREEN_WIDTH, SCREEN_HEIGHT,
)
from bullet import Bullet


class Boss:
    """Base boss class with attack patterns and phases."""

    def __init__(self, x, y, hp, speed, damage, is_final=False):
        self.x = x
        self.y = y
        self.max_health = hp
        self.health = hp
        self.speed = speed
        self.damage = damage
        self.alive = True
        self.is_boss = True
        self.is_final = is_final
        self.width = 50 if not is_final else 72
        self.height = 50 if not is_final else 72
        self.attack_timer = 0.0
        self.attack_pattern = 0
        self.pattern_duration = 4.0
        self.pattern_timer = 0.0
        self.hit_flash = 0.0
        self.death_timer = 0.0
        self.move_dir = (0, 0)
        self.move_timer = 0.0
        self.walk_anim = 0.0
        self.spawn_timer = 6.0  # time between spawning minions (final boss)
        self.shoot_timer = 0.0
        self.rage = False  # enrage at low HP

    def get_rect(self):
        return pygame.Rect(
            self.x - self.width // 2, self.y - self.height // 2,
            self.width, self.height,
        )

    def take_damage(self, amount):
        self.health -= amount
        self.hit_flash = 0.12
        if self.health <= 0:
            self.health = 0
            self.alive = False
            self.death_timer = 1.0
        return not self.alive

    def update(self, dt, player, walls, enemy_bullets, effects, spawn_callback=None):
        if not self.alive:
            if self.death_timer > 0:
                self.death_timer -= dt
            return

        if self.hit_flash > 0:
            self.hit_flash -= dt

        # Rage at 30% HP
        if not self.rage and self.health < self.max_health * 0.3:
            self.rage = True
            self.speed *= 1.3

        # Pattern cycling
        self.pattern_timer += dt
        if self.pattern_timer >= self.pattern_duration:
            self.pattern_timer = 0
            self.attack_pattern = (self.attack_pattern + 1) % self.get_pattern_count()

        # Movement
        self.move_timer -= dt
        if self.move_timer <= 0:
            # Pick a new movement direction toward player with some randomness
            dx = player.x - self.x
            dy = player.y - self.y
            dist = math.hypot(dx, dy)
            if dist > 0:
                self.move_dir = (dx / dist, dy / dist)
            self.move_timer = random.uniform(1.5, 3.0)

        self._move(dt, walls)

        # Attacks
        self._attack(dt, player, walls, enemy_bullets, effects, spawn_callback)

        # Walk animation
        self.walk_anim += dt * 4

    def get_pattern_count(self):
        return 3

    def _move(self, dt, walls):
        dx, dy = self.move_dir
        move_x = dx * self.speed * dt
        move_y = dy * self.speed * dt

        new_x = self.x + move_x
        rect_x = pygame.Rect(new_x - self.width // 2, self.y - self.height // 2, self.width, self.height)
        if not any(rect_x.colliderect(w) for w in walls):
            self.x = new_x

        new_y = self.y + move_y
        rect_y = pygame.Rect(self.x - self.width // 2, new_y - self.height // 2, self.width, self.height)
        if not any(rect_y.colliderect(w) for w in walls):
            self.y = new_y

    def _attack(self, dt, player, walls, enemy_bullets, effects, spawn_callback):
        dist = math.hypot(player.x - self.x, player.y - self.y)
        if dist <= 0:
            return

        dx = (player.x - self.x) / dist
        dy = (player.y - self.y) / dist

        if self.attack_pattern == 0:
            # === Pattern 1: Spread shot (3-5 bullets in a fan) ===
            self.shoot_timer -= dt
            if self.shoot_timer <= 0:
                num_bullets = 5 if self.rage else 3
                spread = math.pi / 4
                for i in range(num_bullets):
                    angle = math.atan2(dy, dx) + (i - num_bullets // 2) * (spread / num_bullets)
                    bdx = math.cos(angle)
                    bdy = math.sin(angle)
                    enemy_bullets.append(Bullet(
                        self.x, self.y, bdx, bdy, 300, self.damage,
                        owner="enemy", size=5
                    ))
                self.shoot_timer = 1.5 if not self.rage else 0.8

        elif self.attack_pattern == 1:
            # === Pattern 2: Circle burst (bullets in all directions) ===
            self.shoot_timer -= dt
            if self.shoot_timer <= 0:
                num = 12 if self.rage else 8
                for i in range(num):
                    angle = (i / num) * math.tau
                    bdx = math.cos(angle)
                    bdy = math.sin(angle)
                    enemy_bullets.append(Bullet(
                        self.x, self.y, bdx, bdy, 250, self.damage,
                        owner="enemy", size=5
                    ))
                self.shoot_timer = 2.5 if not self.rage else 1.5

        elif self.attack_pattern == 2:
            # === Pattern 3: Direct rapid fire ===
            self.shoot_timer -= dt
            if self.shoot_timer <= 0:
                enemy_bullets.append(Bullet(
                    self.x, self.y, dx, dy, 450, self.damage,
                    owner="enemy", size=5
                ))
                self.shoot_timer = 0.3 if self.rage else 0.5

        # Melee on contact
        if dist < self.width + player.width:
            if not hasattr(self, '_melee_cd'):
                self._melee_cd = 0
            self._melee_cd -= dt
            if self._melee_cd <= 0:
                if player.take_damage(self.damage):
                    self._melee_cd = 1.0

        # Final boss spawns minions
        if self.is_final and spawn_callback:
            self.spawn_timer -= dt
            if self.spawn_timer <= 0:
                spawn_callback()
                self.spawn_timer = 8.0 if not self.rage else 5.0

    def draw(self, surface, camera):
        if not self.alive:
            return

        sx, sy = camera.apply(self.x, self.y)
        if sx < -50 or sx > SCREEN_WIDTH + 50 or sy < -50 or sy > SCREEN_HEIGHT + 50:
            return

        flash = self.hit_flash > 0
        body_color = (255, 255, 255) if flash else BOSS_BODY
        dark_color = (200, 200, 200) if flash else BOSS_DARK
        eye_color = (255, 255, 0) if flash else BOSS_EYE

        half = self.width // 2
        bob = int(math.sin(self.walk_anim) * 3)

        # Rage tint
        if self.rage and not flash:
            body_color = (180, 30, 30)
            eye_color = (255, 255, 80)

        # Main body (large pixel-art robot)
        pygame.draw.rect(surface, dark_color, (sx - half - 3, sy - half - 3 + bob, self.width + 6, self.height + 6))
        pygame.draw.rect(surface, body_color, (sx - half, sy - half + bob, self.width, self.height))
        pygame.draw.rect(surface, (20, 10, 30), (sx - half, sy - half + bob, self.width, self.height), 2)

        # Armor plates
        for i in range(3):
            plate_y = sy - half + 4 + i * (self.height // 3) + bob
            pygame.draw.rect(surface, dark_color, (sx - half + 3, plate_y, self.width - 6, self.height // 4))
            pygame.draw.rect(surface, (15, 10, 25), (sx - half + 3, plate_y, self.width - 6, self.height // 4), 1)

        # Eyes (glowing red)
        eye_size = 6 if self.is_final else 5
        pygame.draw.rect(surface, eye_color, (sx - 12, sy - 8 + bob, eye_size, eye_size))
        pygame.draw.rect(surface, eye_color, (sx + 6, sy - 8 + bob, eye_size, eye_size))

        # Core (chest reactor)
        core_color = (255, 100, 100) if self.rage else (200, 80, 200)
        pygame.draw.circle(surface, core_color, (sx, sy + 4 + bob), 5)
        pygame.draw.circle(surface, (255, 200, 200), (sx, sy + 4 + bob), 2)

        # Spikes / horns on top (final boss)
        if self.is_final:
            pygame.draw.polygon(surface, dark_color, [
                (sx - half, sy - half + bob),
                (sx - half + 6, sy - half - 8 + bob),
                (sx - half + 12, sy - half + bob),
            ])
            pygame.draw.polygon(surface, dark_color, [
                (sx + half - 12, sy - half + bob),
                (sx + half - 6, sy - half - 8 + bob),
                (sx + half, sy - half + bob),
            ])


class MiniBoss(Boss):
    """Level 5 mini boss."""

    def __init__(self, x, y):
        super().__init__(x, y, MINI_BOSS_HP, MINI_BOSS_SPEED, MINI_BOSS_DMG, is_final=False)


class FinalBoss(Boss):
    """Level 10 final boss — larger, more HP, spawns minions."""

    def __init__(self, x, y):
        super().__init__(x, y, FINAL_BOSS_HP, FINAL_BOSS_SPEED, FINAL_BOSS_DMG, is_final=True)
        self.pattern_duration = 3.0  # switches patterns faster

    def get_pattern_count(self):
        return 4

    def _attack(self, dt, player, walls, enemy_bullets, effects, spawn_callback):
        if self.attack_pattern == 3:
            # === Pattern 4 (final boss exclusive): Spiral ===
            self.shoot_timer -= dt
            if self.shoot_timer <= 0:
                # Spiral bullets
                for i in range(4):
                    angle = self.walk_anim * 2 + i * (math.pi / 2)
                    bdx = math.cos(angle)
                    bdy = math.sin(angle)
                    enemy_bullets.append(Bullet(
                        self.x, self.y, bdx, bdy, 220, self.damage,
                        owner="enemy", size=6
                    ))
                self.shoot_timer = 0.15 if self.rage else 0.25
            # Also do melee check
            dist = math.hypot(player.x - self.x, player.y - self.y)
            if dist < self.width + player.width:
                if not hasattr(self, '_melee_cd'):
                    self._melee_cd = 0
                self._melee_cd -= dt
                if self._melee_cd <= 0:
                    if player.take_damage(self.damage):
                        self._melee_cd = 1.0
            # Also do spawn
            if self.is_final and spawn_callback:
                self.spawn_timer -= dt
                if self.spawn_timer <= 0:
                    spawn_callback()
                    self.spawn_timer = 8.0 if not self.rage else 5.0
        else:
            super()._attack(dt, player, walls, enemy_bullets, effects, spawn_callback)
