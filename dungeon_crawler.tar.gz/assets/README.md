# DUNGEON TERMINATOR

A 2D top-down pixel-art dungeon crawler built with Python and Pygame.

## Features

- **10 progressively difficult levels** — from tutorial to final boss
- **Mouse aiming + shooting** — your gun rotates toward the cursor, left-click to fire
- **4 enemy types** — Basic, Fast (aggressive), Ranged (shoots projectiles), Tank (high HP)
- **2 boss fights** — Mini Boss on Level 5, Final Boss on Level 10
- **Camera system** — smoothly follows the player through large dungeons
- **Procedurally generated dungeons** — rooms + corridors, different every run
- **Particle effects** — muzzle flash, hit sparks, death explosions, floating damage numbers
- **Screen shake** — on hits, explosions, and boss attacks
- **Health pickups** — scattered through later levels
- **Synth sound effects** — generated procedurally (no external files needed)
- **Main menu + Pause menu** — with controls display
- **Boss health bars** — large bars at the top of the screen

## Controls

| Key | Action |
|-----|--------|
| Arrow Keys / WASD | Move |
| Mouse | Aim gun |
| Left Click | Shoot |
| ESC | Pause / Menu |
| R | Restart level (after death) |
| ENTER | Start game / Continue |

## Requirements

- Python 3.8+
- Pygame

## Installation

```bash
pip install pygame
```

## How to Run

```bash
cd dungeon_crawler
python main.py
```

## Project Structure

```
dungeon_crawler/
├── main.py         # Game entry point, state machine, game loop
├── settings.py     # All constants, colors, level configs
├── player.py       # Player class (movement, aiming, shooting)
├── enemy.py        # Enemy classes (Basic, Fast, Ranged, Tank)
├── boss.py         # Mini Boss and Final Boss
├── bullet.py       # Bullet/projectile system
├── dungeon.py      # Procedural dungeon generation
├── level.py        # Level management, enemy spawning, exit logic
├── camera.py       # Smooth camera that follows the player
├── ui.py           # HUD, health bars, transitions, death/win screens
├── menu.py         # Main menu and controls screen
├── effects.py      # Particles, damage numbers, muzzle flash, screen shake
└── README.md       # This file
```

## Level Progression

| Level | Enemies | Boss | Description |
|-------|---------|------|-------------|
| 1 | 5 | — | Tutorial: learn controls |
| 2 | 8 | — | Basic + fast enemies |
| 3 | 12 | — | Ranged enemies introduced |
| 4 | 15 | — | Health pickups introduced |
| 5 | 16 | Mini Boss | First boss fight |
| 6 | 20 | — | Tank enemies + maze maps |
| 7 | 25 | — | Aggressive AI |
| 8 | 30 | — | Large multi-room dungeons |
| 9 | 35 | — | Final preparation |
| 10 | 10 + Final Boss | Final Boss | Multi-pattern boss fight |

## How It Works

- **Dungeon generation**: Rooms are placed randomly and connected with L-shaped corridors. BFS ensures a path always exists from spawn to exit.
- **Combat**: Left-click fires bullets toward the mouse cursor. Bullets check collision against walls and enemies each frame. Enemies have AI that chases, strafes, or keeps distance based on type.
- **Boss patterns**: Bosses cycle through attack patterns (spread shot, circle burst, rapid fire, spiral for final boss) and enrage at 30% HP.
- **Camera**: Lerps toward the player position, clamped to dungeon bounds, with screen shake on impacts.
- **Sound**: Synthesized using numpy + pygame.mixer. Falls back gracefully if numpy or mixer is unavailable.

Enjoy!
