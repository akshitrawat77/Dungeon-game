"""
settings.py — Global constants and configuration for Dungeon Terminator.
"""

# === Display ===
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60
TILE_SIZE = 32

# === Colors (dark futuristic palette) ===
BLACK        = (0, 0, 0)
WHITE        = (240, 240, 245)
DARK_BG      = (8, 10, 18)
HUD_BG       = (14, 16, 28)
HUD_BORDER   = (60, 80, 120)

# Walls
WALL_COLOR     = (45, 50, 68)
WALL_HIGHLIGHT = (70, 78, 100)
WALL_SHADOW    = (28, 32, 44)
WALL_EDGE      = (90, 100, 140)

# Floor
FLOOR_COLOR     = (22, 26, 38)
FLOOR_COLOR_ALT = (26, 30, 44)
FLOOR_GRID      = (32, 38, 54)

# Exit
EXIT_LOCKED = (180, 40, 40)
EXIT_OPEN   = (40, 200, 100)
EXIT_GLOW   = (100, 255, 150)

# Player
PLAYER_BODY    = (80, 140, 240)
PLAYER_DARK    = (40, 70, 140)
PLAYER_LIGHT   = (130, 180, 255)
PLAYER_HELMET  = (60, 70, 90)
PLAYER_VISOR   = (100, 220, 255)

# Gun
GUN_BODY    = (120, 120, 130)
GUN_DARK    = (70, 70, 80)
GUN_BARREL  = (160, 160, 175)
MUZZLE_FLASH = (255, 230, 120)

# Bullets
BULLET_PLAYER  = (120, 220, 255)
BULLET_ENEMY   = (255, 80, 80)
BULLET_TRAIL_P = (60, 140, 200)
BULLET_TRAIL_E = (200, 50, 50)

# Enemies
ENEMY_BASIC  = (200, 50, 50)
ENEMY_FAST   = (255, 160, 40)
ENEMY_RANGED = (180, 80, 220)
ENEMY_TANK   = (100, 100, 120)
ENEMY_EYE    = (255, 220, 40)

# Boss
BOSS_BODY   = (100, 30, 160)
BOSS_DARK   = (60, 15, 100)
BOSS_EYE   = (255, 50, 50)
BOSS_HP_BAR = (200, 40, 200)

# UI
HP_GREEN  = (50, 220, 80)
HP_RED    = (220, 50, 50)
HP_BG    = (30, 15, 15)
UI_GOLD  = (220, 180, 40)
UI_NEON  = (80, 200, 255)

# Health pickup
HEALTH_GREEN  = (50, 220, 80)
HEALTH_DARK   = (20, 100, 40)

# Particles
PARTICLE_HIT    = (255, 200, 80)
PARTICLE_DEATH  = (255, 100, 50)
PARTICLE_SPARK  = (200, 220, 255)

# Online status colors
ONLINE_GREEN  = (50, 220, 80)
OFFLINE_RED   = (220, 50, 50)

# === Player settings ===
PLAYER_MAX_HP     = 100
PLAYER_SPEED      = 240   # pixels per second
PLAYER_SHOOT_CD   = 0.18  # seconds between shots
BULLET_SPEED       = 680
BULLET_DAMAGE      = 25
BULLET_LIFETIME    = 1.2   # seconds
MUZZLE_FLASH_TIME  = 0.06
PLAYER_HIT_CD      = 0.5   # invulnerability after hit
PLAYER_RECOIL      = 3     # pixels knockback

# === Enemy type configurations ===
ENEMY_TYPES = {
    "basic": {
        "hp": 30, "speed": 80, "damage": 12,
        "range": 250, "attack_cd": 0.8, "score": 100,
        "size": 24, "color": ENEMY_BASIC,
    },
    "fast": {
        "hp": 18, "speed": 180, "damage": 8,
        "range": 350, "attack_cd": 0.5, "score": 150,
        "size": 18, "color": ENEMY_FAST,
    },
    "ranged": {
        "hp": 25, "speed": 60, "damage": 10,
        "range": 400, "attack_cd": 1.5, "score": 200,
        "size": 22, "color": ENEMY_RANGED,
        "bullet_speed": 350, "bullet_damage": 10,
    },
    "tank": {
        "hp": 120, "speed": 45, "damage": 25,
        "range": 200, "attack_cd": 1.2, "score": 300,
        "size": 30, "color": ENEMY_TANK,
    },
}

# === Level configurations ===
LEVELS = [
    # Level 1 — Tutorial
    {"enemies": 5,  "w": 30, "h": 22, "types": ["basic"], "boss": None,
     "objective": "DEFEAT ALL ENEMIES TO UNLOCK THE EXIT", "tutorial": True,
     "health_pickups": 0},
    # Level 2
    {"enemies": 8,  "w": 36, "h": 24, "types": ["basic", "basic", "fast"], "boss": None,
     "objective": "ELIMINATE ALL HOSTILES", "tutorial": False,
     "health_pickups": 0},
    # Level 3 — Ranged enemies introduced
    {"enemies": 12, "w": 40, "h": 28, "types": ["basic", "fast", "ranged"], "boss": None,
     "objective": "ELIMINATE ALL HOSTILES", "tutorial": False,
     "health_pickups": 1},
    # Level 4
    {"enemies": 15, "w": 42, "h": 30, "types": ["fast", "fast", "ranged", "basic"], "boss": None,
     "objective": "ELIMINATE ALL HOSTILES", "tutorial": False,
     "health_pickups": 2},
    # Level 5 — Mini Boss
    {"enemies": 16, "w": 44, "h": 32, "types": ["basic", "fast", "ranged"], "boss": "mini",
     "objective": "DEFEAT THE MINI BOSS", "tutorial": False,
     "health_pickups": 2},
    # Level 6
    {"enemies": 20, "w": 48, "h": 34, "types": ["basic", "fast", "ranged", "tank"], "boss": None,
     "objective": "ELIMINATE ALL HOSTILES", "tutorial": False,
     "health_pickups": 3},
    # Level 7 — Advanced enemies
    {"enemies": 25, "w": 52, "h": 36, "types": ["fast", "fast", "ranged", "tank", "basic"], "boss": None,
     "objective": "ELIMINATE ALL HOSTILES", "tutorial": False,
     "health_pickups": 3},
    # Level 8 — Large dungeon
    {"enemies": 30, "w": 56, "h": 40, "types": ["fast", "ranged", "tank", "basic"], "boss": None,
     "objective": "ELIMINATE ALL HOSTILES", "tutorial": False,
     "health_pickups": 4},
    # Level 9 — Boss prep
    {"enemies": 35, "w": 58, "h": 42, "types": ["fast", "ranged", "ranged", "tank", "basic"], "boss": None,
     "objective": "REACH THE FINAL CHAMBER", "tutorial": False,
     "health_pickups": 4, "pre_boss": True},
    # Level 10 — Final Boss
    {"enemies": 10, "w": 40, "h": 30, "types": ["fast", "ranged"], "boss": "final",
     "objective": "DEFEAT THE FINAL BOSS", "tutorial": False,
     "health_pickups": 3, "final_boss": True},
]

MAX_LEVELS = 10

# === Boss settings ===
MINI_BOSS_HP   = 400
MINI_BOSS_SPEED = 70
MINI_BOSS_DMG  = 20

FINAL_BOSS_HP   = 800
FINAL_BOSS_SPEED = 60
FINAL_BOSS_DMG  = 25

# === Game states ===
STATE_MENU     = "menu"
STATE_PLAYING  = "playing"
STATE_PAUSED   = "paused"
STATE_DEAD     = "dead"
STATE_TRANSITION = "transition"
STATE_LEVEL_COMPLETE = "level_complete"
STATE_WIN      = "win"
STATE_CONTROLS = "controls"
STATE_USERNAME = "username"
STATE_LEADERBOARD = "leaderboard"
STATE_SUBMITTING = "submitting"
STATE_SCORE_RESULT = "score_result"

# === Font sizes ===
FONT_SMALL  = 14
FONT_MEDIUM = 20
FONT_LARGE = 32
FONT_XL     = 56

# === Camera ===
CAMERA_LERP = 5.0
CAMERA_OFFSET_X = 0
CAMERA_OFFSET_Y = -40

# === Transition timing ===
FADE_IN_TIME  = 0.5
FADE_OUT_TIME = 0.5
LEVEL_TEXT_TIME = 2.0
