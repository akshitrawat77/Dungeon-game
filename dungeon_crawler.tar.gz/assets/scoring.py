"""
scoring.py — Scoring system for Dungeon Terminator.

Tracks enemy kill points, level completion bonuses, time bonuses,
survival bonuses, and the final score.
"""

# === Score values per enemy type (configurable) ===
ENEMY_SCORES = {
    "basic":  100,
    "fast":   150,
    "ranged": 200,
    "tank":   300,
    "mini_boss":  1000,
    "final_boss": 5000,
}

# === Level completion bonuses (configurable) ===
LEVEL_BONUSES = {
    1: 500,   2: 750,   3: 1000,  4: 1250,  5: 1500,
    6: 1750,  7: 2000,  8: 2500,  9: 3000,  10: 5000,
}

# === Time bonus config ===
# Max time per level (seconds) to get any time bonus.
# Faster completion = higher bonus (scaled linearly).
TIME_BONUS_MAX_PER_LEVEL = 180   # 3 minutes for full bonus
TIME_BONUS_CAP = 1500            # max time bonus per level
TIME_BONUS_MIN = 100             # minimum time bonus if completed

# === Survival bonuses ===
SURVIVAL_BONUS = 500       # per level completed without dying
PERFECT_RUN_BONUS = 10000  # entire game completed without a single death


class ScoreManager:
    """Central score tracker for a single playthrough."""

    def __init__(self):
        self.total_score = 0
        self.enemies_defeated = 0
        self.deaths_this_run = 0
        self.deaths_this_level = 0
        self.level_start_time = 0.0
        self.game_start_time = 0.0
        self.total_time = 0.0
        self.current_level = 1
        self.completed_game = False
        self.level_scores = {}  # level_num -> breakdown dict
        self.highest_level = 1

    def start_game(self, current_time):
        """Call when a new game starts."""
        self.total_score = 0
        self.enemies_defeated = 0
        self.deaths_this_run = 0
        self.game_start_time = current_time
        self.level_scores = {}
        self.completed_game = False
        self.highest_level = 1

    def start_level(self, level_num, current_time):
        """Call when a level starts."""
        self.current_level = level_num
        self.level_start_time = current_time
        self.deaths_this_level = 0
        if level_num > self.highest_level:
            self.highest_level = level_num

    def add_enemy_kill(self, enemy_type):
        """Add points for killing an enemy."""
        points = ENEMY_SCORES.get(enemy_type, 100)
        self.total_score += points
        self.enemies_defeated += 1
        return points

    def register_death(self):
        """Register a player death (for survival bonus tracking)."""
        self.deaths_this_run += 1
        self.deaths_this_level += 1

    def complete_level(self, level_num, completion_time):
        """Calculate and add all level-completion bonuses.

        Returns a dict with the breakdown:
          { kill_score, level_bonus, time_bonus, survival_bonus, level_total, time }
        """
        level_bonus = LEVEL_BONUSES.get(level_num, 500)

        # Time bonus: linear scale, faster = more
        if completion_time <= TIME_BONUS_MAX_PER_LEVEL:
            ratio = 1.0 - (completion_time / TIME_BONUS_MAX_PER_LEVEL)
            time_bonus = int(TIME_BONUS_MIN + (TIME_BONUS_CAP - TIME_BONUS_MIN) * ratio)
        else:
            time_bonus = TIME_BONUS_MIN

        # Survival bonus: no deaths this level
        survival_bonus = SURVIVAL_BONUS if self.deaths_this_level == 0 else 0

        level_total = level_bonus + time_bonus + survival_bonus
        self.total_score += level_total

        breakdown = {
            "level_bonus": level_bonus,
            "time_bonus": time_bonus,
            "survival_bonus": survival_bonus,
            "level_total": level_total,
            "time": completion_time,
            "deaths": self.deaths_this_level,
        }
        self.level_scores[level_num] = breakdown
        return breakdown

    def complete_game(self, total_time):
        """Call when the entire game (all 10 levels) is completed.
        Adds the perfect run bonus if applicable."""
        self.completed_game = True
        self.total_time = total_time

        if self.deaths_this_run == 0:
            self.total_score += PERFECT_RUN_BONUS
            return PERFECT_RUN_BONUS
        return 0

    def get_completion_time(self, current_time):
        """Get total elapsed game time."""
        return current_time - self.game_start_time

    def get_level_time(self, current_time):
        """Get elapsed time for the current level."""
        return current_time - self.level_start_time

    def get_total_data(self):
        """Get data for API submission."""
        return {
            "score": self.total_score,
            "level": self.highest_level,
            "completion_time": int(self.total_time),
            "enemies_defeated": self.enemies_defeated,
            "completed_game": self.completed_game,
        }
