"""
online/leaderboard.py — In-game leaderboard display for Dungeon Terminator.

Renders the leaderboard table, loading states, and error handling
directly on the pygame screen.
"""

import pygame
from settings import (
    SCREEN_WIDTH, SCREEN_HEIGHT, DARK_BG, WHITE, UI_GOLD, UI_NEON,
    FONT_SMALL, FONT_MEDIUM, FONT_LARGE, FONT_XL,
    HUD_BG, HUD_BORDER,
)
from online.api import get_leaderboard, get_player_rank, format_score, format_time


class LeaderboardView:
    """In-game leaderboard display with loading and error states."""

    def __init__(self):
        self.entries = []
        self.loading = False
        self.error = None
        self.last_fetch_time = 0
        self.player_rank_data = None
        self.scroll_y = 0
        self.max_scroll = 0
        self.last_username = ""
        self.last_score = 0

    def fetch(self, username="", score=0):
        """Fetch leaderboard data from the backend."""
        self.loading = True
        self.error = None
        self.last_username = username
        self.last_score = score

        result = get_leaderboard()
        if result.get("success"):
            self.entries = result.get("leaderboard", [])
            self.loading = False
            self.error = None
        else:
            self.loading = False
            self.error = result.get("error", "Failed to load leaderboard")
            self.entries = []

        # Fetch player rank if username provided
        if username and score > 0:
            rank_result = get_player_rank(username, score)
            if rank_result.get("success"):
                self.player_rank_data = rank_result
            else:
                self.player_rank_data = None

        self.last_fetch_time = pygame.time.get_ticks() / 1000.0
        self.scroll_y = 0
        self._calc_max_scroll()

    def retry(self):
        """Retry fetching."""
        self.fetch(self.last_username, self.last_score)

    def _calc_max_scroll(self):
        """Calculate max scroll offset."""
        row_height = 32
        total_height = len(self.entries) * row_height
        view_height = SCREEN_HEIGHT - 240
        self.max_scroll = max(0, total_height - view_height)

    def handle_event(self, event):
        """Handle keyboard input for scrolling and retry."""
        if event.type != pygame.KEYDOWN:
            return None

        if event.key == pygame.K_ESCAPE:
            return "back"
        elif event.key == pygame.K_r and self.error:
            self.retry()
        elif event.key == pygame.K_UP or event.key == pygame.K_w:
            self.scroll_y = max(0, self.scroll_y - 40)
        elif event.key == pygame.K_DOWN or event.key == pygame.K_s:
            self.scroll_y = min(self.max_scroll, self.scroll_y + 40)
        elif event.key == pygame.K_PAGEUP:
            self.scroll_y = max(0, self.scroll_y - 200)
        elif event.key == pygame.K_PAGEDOWN:
            self.scroll_y = min(self.max_scroll, self.scroll_y + 200)
        return None

    def update(self, dt):
        pass

    def draw(self, surface):
        """Draw the leaderboard screen."""
        surface.fill(DARK_BG)

        # Background grid
        for x in range(0, SCREEN_WIDTH, 40):
            pygame.draw.line(surface, (14, 16, 28), (x, 0), (x, SCREEN_HEIGHT))
        for y in range(0, SCREEN_HEIGHT, 40):
            pygame.draw.line(surface, (14, 16, 28), (0, y), (SCREEN_WIDTH, y))

        # Title
        title_font = pygame.font.SysFont("consolas", FONT_XL, bold=True)
        title = title_font.render("LEADERBOARD", True, UI_GOLD)
        surface.blit(title, (SCREEN_WIDTH // 2 - title.get_width() // 2, 30))

        subtitle_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)
        sub = subtitle_font.render("GLOBAL TOP 100", True, UI_NEON)
        surface.blit(sub, (SCREEN_WIDTH // 2 - sub.get_width() // 2, 75))

        if self.loading:
            self._draw_loading(surface)
        elif self.error:
            self._draw_error(surface)
        else:
            self._draw_table(surface)

        # Footer
        hint_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)
        hint = hint_font.render("ESC to go back  |  UP/DOWN to scroll  |  R to retry", True, (80, 90, 110))
        surface.blit(hint, (SCREEN_WIDTH // 2 - hint.get_width() // 2, SCREEN_HEIGHT - 30))

    def _draw_loading(self, surface):
        """Draw loading state."""
        font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
        text = font.render("LOADING LEADERBOARD...", True, UI_NEON)
        surface.blit(text, (SCREEN_WIDTH // 2 - text.get_width() // 2, SCREEN_HEIGHT // 2))

    def _draw_error(self, surface):
        """Draw error state with retry button."""
        font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
        error = font.render("UNABLE TO LOAD LEADERBOARD", True, (255, 80, 80))
        surface.blit(error, (SCREEN_WIDTH // 2 - error.get_width() // 2, SCREEN_HEIGHT // 2 - 30))

        sub_font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
        msg = sub_font.render(self.error or "Unknown error", True, (200, 100, 100))
        surface.blit(msg, (SCREEN_WIDTH // 2 - msg.get_width() // 2, SCREEN_HEIGHT // 2 + 10))

        retry = sub_font.render("[ R ] RETRY", True, UI_NEON)
        surface.blit(retry, (SCREEN_WIDTH // 2 - retry.get_width() // 2, SCREEN_HEIGHT // 2 + 50))

    def _draw_table(self, surface):
        """Draw the leaderboard table."""
        if not self.entries:
            font = pygame.font.SysFont("consolas", FONT_LARGE, bold=True)
            empty = font.render("NO SCORES YET — BE THE FIRST!", True, (150, 160, 180))
            surface.blit(empty, (SCREEN_WIDTH // 2 - empty.get_width() // 2, SCREEN_HEIGHT // 2))
            return

        # Table header
        header_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)
        col_x = [60, 140, 400, 700, 900, 1050]
        headers = ["#", "PLAYER", "SCORE", "LVL", "TIME", "STATUS"]

        header_y = 110
        for i, h in enumerate(headers):
            color = UI_GOLD if i in (0, 2) else UI_NEON
            text = header_font.render(h, True, color)
            surface.blit(text, (col_x[i], header_y))

        # Separator line
        pygame.draw.line(surface, HUD_BORDER, (50, header_y + 22), (SCREEN_WIDTH - 50, header_y + 22), 1)

        # Table rows
        row_font = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)
        row_height = 32
        start_y = 140
        view_height = SCREEN_HEIGHT - 240

        # Clip to view area
        clip_rect = pygame.Rect(40, start_y, SCREEN_WIDTH - 80, view_height)
        prev_clip = surface.get_clip()
        surface.set_clip(clip_rect)

        for i, entry in enumerate(self.entries):
            y = start_y + i * row_height - self.scroll_y

            if y < start_y - row_height or y > start_y + view_height:
                continue

            # Alternating row background
            if i % 2 == 0:
                bg = (16, 18, 30)
            else:
                bg = (20, 22, 36)
            pygame.draw.rect(surface, bg, (40, y, SCREEN_WIDTH - 80, row_height))

            # Highlight top 3
            rank = entry.get("rank", i + 1)
            rank_color = UI_GOLD if rank <= 3 else WHITE
            if rank == 1:
                rank_color = (255, 215, 0)
            elif rank == 2:
                rank_color = (192, 192, 200)
            elif rank == 3:
                rank_color = (205, 127, 50)

            # Rank
            surface.blit(row_font.render(f"#{rank}", True, rank_color), (col_x[0], y + 8))
            # Username
            surface.blit(row_font.render(entry.get("username", "???"), True, WHITE), (col_x[1], y + 8))
            # Score
            score_text = format_score(entry.get("score", 0))
            surface.blit(row_font.render(score_text, True, UI_GOLD), (col_x[2], y + 8))
            # Level
            surface.blit(row_font.render(str(entry.get("level", 1)), True, UI_NEON), (col_x[3], y + 8))
            # Time
            time_text = format_time(entry.get("time", 0))
            surface.blit(row_font.render(time_text, True, (150, 160, 180)), (col_x[4], y + 8))
            # Completed
            completed = entry.get("completed", False)
            status = "COMPLETE" if completed else "DEAD"
            status_color = (50, 220, 80) if completed else (255, 100, 100)
            surface.blit(row_font.render(status, True, status_color), (col_x[5], y + 8))

        surface.set_clip(prev_clip)

        # Player rank section at bottom
        if self.player_rank_data and self.player_rank_data.get("success"):
            self._draw_player_rank(surface)

    def _draw_player_rank(self, surface):
        """Draw the player's personal rank and nearby scores."""
        rank_data = self.player_rank_data
        nearby = rank_data.get("nearby", [])
        rank = rank_data.get("rank", "?")
        total = rank_data.get("total_players", 0)

        y_start = SCREEN_HEIGHT - 110
        pygame.draw.rect(surface, HUD_BG, (40, y_start, SCREEN_WIDTH - 80, 70))
        pygame.draw.rect(surface, HUD_BORDER, (40, y_start, SCREEN_WIDTH - 80, 70), 1)

        font = pygame.font.SysFont("consolas", FONT_MEDIUM, bold=True)
        small = pygame.font.SysFont("consolas", FONT_SMALL, bold=True)

        title = small.render("YOUR RANK", True, UI_NEON)
        surface.blit(title, (60, y_start + 5))

        rank_text = font.render(f"#{rank} / {total}", True, UI_GOLD)
        surface.blit(rank_text, (60, y_start + 22))

        # Nearby scores
        x = 250
        if nearby:
            for entry in nearby:
                prefix = ">>" if entry.get("is_you") else "  "
                name = entry.get("username", "???")
                score = format_score(entry.get("score", 0))
                color = UI_NEON if entry.get("is_you") else (150, 160, 180)
                text = small.render(f"{prefix}#{entry.get('rank','?')} {name} {score}", True, color)
                surface.blit(text, (x, y_start + 28))
                x += 220
                if x > SCREEN_WIDTH - 200:
                    break
