"""
online/api.py — HTTP client for the Dungeon Terminator leaderboard backend.

Handles all communication with the server: status check, score submission,
leaderboard retrieval, and player rank lookup.
Works in desktop Python (urllib) and pygbag/WebAssembly (XMLHttpRequest + postMessage).
"""

import json
import time

# === Backend API base URL ===
API_BASE = "https://koda-4771d1d0.base44.app/functions"

# Timeout for HTTP requests (seconds)
TIMEOUT = 5


def _is_browser():
    """Check if we're running in pygbag/WebAssembly browser environment."""
    try:
        import platform as _pf
        return hasattr(_pf, 'window') and _pf.window is not None
    except Exception:
        return False


def _http_request(method, path, data=None):
    """Make an HTTP request. Returns (success, response_dict).

    Uses XMLHttpRequest in browser (pygbag), urllib on desktop.
    """
    url = f"{API_BASE}/{path}"

    # === Browser path: XMLHttpRequest ===
    if _is_browser():
        try:
            return _http_xhr(method, url, data)
        except Exception as e:
            # Fall through to urllib if XHR fails completely
            print(f"[API] XHR failed: {e}, trying urllib...")

    # === Desktop path: urllib ===
    import urllib.request
    import urllib.error

    try:
        if data is not None:
            body = json.dumps(data).encode("utf-8")
            req = urllib.request.Request(
                url, data=body, method=method,
                headers={"Content-Type": "application/json"}
            )
        else:
            req = urllib.request.Request(url, method=method)

        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return True, result
    except urllib.error.URLError:
        return False, {"error": "Network error — server unreachable"}
    except urllib.error.HTTPError as e:
        try:
            result = json.loads(e.read().decode("utf-8"))
            return False, result
        except Exception:
            return False, {"error": f"HTTP {e.code}"}
    except Exception as e:
        return False, {"error": str(e)}


def _http_xhr(method, url, data=None):
    """Make a synchronous XMLHttpRequest from the browser (pygbag)."""
    import platform as _pf

    # Create XMLHttpRequest — try multiple approaches for compatibility
    xhr = None
    try:
        xhr = _pf.window.XMLHttpRequest.new()
    except Exception:
        try:
            xhr = _pf.window.XMLHttpRequest()
        except Exception:
            try:
                xhr = _pf.window.eval("new XMLHttpRequest()")
            except Exception as e:
                raise Exception(f"Cannot create XMLHttpRequest: {e}")

    xhr.open(method, url, False)  # synchronous
    xhr.setRequestHeader("Content-Type", "application/json")

    if data is not None:
        xhr.send(json.dumps(data))
    else:
        xhr.send()

    status = int(xhr.status)
    response_text = xhr.responseText

    if 200 <= status < 300:
        return True, json.loads(response_text)
    else:
        try:
            return False, json.loads(response_text)
        except Exception:
            return False, {"error": f"HTTP {status}"}


def check_status():
    """Check if the backend is online. Returns True/False."""
    if _is_browser():
        # In browser, assume online — the parent page handles status display
        return True
    success, data = _http_request("GET", "checkStatus")
    return success and data.get("status") == "online"


def submit_score(username, score, level, completion_time, enemies_defeated, completed_game):
    """Submit a score to the global leaderboard.

    Returns: {success, new_record, rank, score, error}
    """
    payload = {
        "username": username,
        "score": int(score),
        "level": int(level),
        "completion_time": int(completion_time),
        "enemies_defeated": int(enemies_defeated),
        "completed_game": bool(completed_game),
    }

    # In browser, send score to parent page via postMessage
    # The parent page (landing page) handles the actual API submission
    if _is_browser():
        try:
            import platform as _pf
            msg = {
                "type": "SUBMIT_SCORE",
                "payload": payload
            }
            _pf.window.parent.postMessage(msg, "*")
            return {"success": True, "message": "Score sent to parent page"}
        except Exception as e:
            print(f"[API] postMessage failed: {e}")
            # Fall through to XHR
            success, data = _http_request("POST", "submitScore", payload)
            if success:
                return data
            return {"success": False, "error": data.get("error", "Submission failed")}

    # Desktop path
    success, data = _http_request("POST", "submitScore", payload)
    if success:
        return data
    return {
        "success": False,
        "error": data.get("error", "Submission failed"),
    }


def get_leaderboard():
    """Fetch the global top 100 leaderboard.

    Returns: {success, leaderboard: [...], total} or {success: False, error}
    """
    success, data = _http_request("GET", "getLeaderboard")
    if success:
        return data
    return {"success": False, "error": data.get("error", "Failed to load"), "leaderboard": []}


def get_player_rank(username, score):
    """Get a player's rank and nearby scores.

    Returns: {success, rank, nearby: [...], total_players} or {success: False, error}
    """
    payload = {"username": username, "score": int(score)}
    success, data = _http_request("POST", "getPlayerRank", payload)
    if success:
        return data
    return {"success": False, "error": data.get("error", "Failed to get rank")}


def sanitize_username(name):
    """Sanitize a username for submission.

    - Strip whitespace
    - Max 20 chars
    - Allow only alphanumeric, underscore, hyphen
    Returns (valid, cleaned_name, error_msg)
    """
    if not name:
        return False, "", "Username cannot be empty"
    cleaned = name.strip()[:20]
    if len(cleaned) < 3:
        return False, cleaned, "Username must be at least 3 characters"
    if len(cleaned) > 20:
        return False, cleaned, "Username too long (max 20 chars)"
    import re
    if not re.match(r'^[a-zA-Z0-9_-]+$', cleaned):
        return False, cleaned, "Only letters, numbers, _ and - allowed"
    return True, cleaned, None


def format_score(score):
    """Format a score with comma separators."""
    return f"{int(score):,}"


def format_time(seconds):
    """Format seconds as MM:SS."""
    mins = int(seconds) // 60
    secs = int(seconds) % 60
    return f"{mins:02d}:{secs:02d}"
