# Dungeon Terminator — Deployment Guide

This guide explains how to deploy Dungeon Terminator so anyone can play it from a URL, with the global leaderboard fully functional.

---

## Architecture Overview

```
Browser (Player)           Backend (Base44)           Database (Base44 Entity)
┌──────────────┐          ┌──────────────────┐       ┌──────────────────┐
│  index.html  │──POST───▶│ /functions/      │──────▶│ Leaderboard      │
│  game (WASM) │          │  submitScore     │       │ (entity records) │
│  leaderboard │──GET────▶│ /functions/      │◀──────│                  │
│              │          │  getLeaderboard  │       └──────────────────┘
└──────────────┘          └──────────────────┘
```

- **Frontend**: HTML landing page + pygbag-compiled game (WebAssembly)
- **Backend**: Base44 serverless functions (already deployed)
- **Database**: Base44 Leaderboard entity (already created)

---

## Step 1: Install Dependencies

```bash
pip install pygame pygbag numpy
```

## Step 2: Build the Browser Version

```bash
cd dungeon_crawler
pygbag --build .
```

This produces a `build/web/` directory containing:
- `index.html` — the game canvas
- JavaScript and WASM files
- All assets bundled

### Important: Pygbag Compatibility

The game uses `pygame.time.Clock()` and a standard game loop. Pygbag handles this automatically — it patches pygame to work in the browser. No code changes needed for basic compatibility.

However, HTTP requests (for the leaderboard) use `urllib.request`, which pygbag also patches to work asynchronously in the browser.

If you encounter issues with pygbag:
1. Make sure the main loop doesn't block (pygbag handles this)
2. If sound doesn't work, the game already falls back gracefully
3. Test with `pygbag --build . --verbose` for debugging

## Step 3: Host the Website

You need two things hosted:
1. The pygbag build (the game itself)
2. The landing page (index.html, style.css, scripts.js from the `web/` folder)

### Option A: GitHub Pages (Free, Recommended)

1. Create a GitHub repository
2. Copy the `web/` folder contents to the repo root
3. Copy the pygbag build output to `game/` in the repo
4. Enable GitHub Pages in repo settings (Settings → Pages → Source → main branch)
5. Your site will be at `https://username.github.io/repo-name/`

### Option B: Netlify (Free, Easy)

1. Drag and drop your website folder onto [netlify.com/drop](https://app.netlify.com/drop)
2. The folder should contain:
   ```
   index.html
   style.css
   scripts.js
   game/
     index.html  (pygbag build)
     ... (WASM/JS files)
   ```

### Option C: Any Static Host

The website is pure static files — host it anywhere:
- Vercel
- Cloudflare Pages
- Your own server
- S3 bucket

## Step 4: Backend Configuration

The backend is already deployed and running! The API endpoints are:

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `https://koda-4771d1d0.base44.app/functions/checkStatus` | GET | Online status check |
| `https://koda-4771d1d0.base44.app/functions/submitScore` | POST | Submit a score |
| `https://koda-4771d1d0.base44.app/functions/getLeaderboard` | GET | Get top 100 |
| `https://koda-4771d1d0.base44.app/functions/getPlayerRank` | POST | Get player rank |

All endpoints have CORS enabled (`Access-Control-Allow-Origin: *`) so they work from any website.

No API keys are exposed in the frontend. The backend validates all submissions server-side.

## Step 5: Environment Variables

There are NO environment variables or secrets to configure. The backend functions use Base44's built-in authentication and database. No API keys are needed.

## Step 6: Connect Game to Backend

The game's API client (`online/api.py`) is pre-configured with the backend URL:
```python
API_BASE = "https://koda-4771d1d0.base44.app/functions"
```

If you change the backend, update this URL in `dungeon_crawler/online/api.py`.

## Step 7: Test Score Submission

1. Open the deployed website
2. Click PLAY GAME
3. Enter a username (3+ characters, letters/numbers/_/-)
4. Play and complete levels
5. At the end (death or victory), press ENTER to submit score
6. Check the leaderboard — your score should appear

### Test from Two Devices

1. Open the website on your computer — play, submit a score
2. Open the website on your phone or another computer — check the leaderboard
3. Both devices should see the same scores

## Step 8: Verify Anti-Cheat

The backend rejects:
- Scores > 150,000 (impossible max)
- Completion time < 120 seconds for a full game clear
- Enemy count > 200
- Empty or invalid usernames
- Submissions faster than 2 minutes apart (rate limiting)
- Scores that don't beat the player's personal best (only the best is kept)

## Step 9: Folder Structure for Deployment

```
your-website/
├── index.html          ← Landing page (from web/ folder)
├── style.css           ← Styles (from web/ folder)
├── scripts.js          ← Leaderboard JS (from web/ folder)
└── game/               ← Pygbag build output
    ├── index.html      ← Game canvas
    ├── ...             ← WASM/JS files
```

## Offline Fallback

If the player loses internet:
- The main menu shows "OFFLINE" status
- The game is still fully playable
- Score submission shows "Offline mode — score not uploaded"
- The game never crashes due to network issues

## Troubleshooting

### Game doesn't load in browser
- Check browser console (F12) for errors
- Make sure pygbag build completed successfully
- Try a different browser (Chrome/Firefox recommended)

### Leaderboard doesn't load
- Check that `https://koda-4771d1d0.base44.app/functions/getLeaderboard` returns data
- Check browser console for CORS errors
- The backend functions have CORS enabled, but if you change the backend URL, ensure CORS headers are set

### Score not submitting
- Check online status indicator (must show ONLINE)
- Wait 2 minutes between submissions (rate limiting)
- Username must be 3-20 chars, alphanumeric/_/-
- Score must be > 0 and < 150,000

### Sound doesn't work in browser
- Browsers require user interaction before playing audio
- The game already handles this gracefully — sounds just won't play until you click

---

## Summary

| Component | Technology | Status |
|-----------|-----------|--------|
| Game | Python + Pygame | ✅ Ready |
| Browser version | Pygbag (WebAssembly) | ✅ Ready |
| Landing page | HTML/CSS/JS | ✅ Ready |
| Backend API | Base44 Functions | ✅ Deployed |
| Database | Base44 Entity | ✅ Created |
| Anti-cheat | Server-side validation | ✅ Active |
| CORS | All endpoints | ✅ Enabled |
